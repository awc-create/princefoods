// src/app/cart/CartClient.tsx
'use client';

import { useCart } from '@/lib/cart-store';
import { penceToGBP } from '@/lib/money';
import { Minus, Plus, Trash2 } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import styles from './cart.module.scss';

interface OffersSnapshot {
  discountPence: number;
  applied: { offerId: string; name: string; kind: string; discountPence: number }[];
  autoAdd: { reasonOfferId: string; name: string; qty: number }[];
}

interface OffersQuoteApiResp {
  result?: {
    discountTotalPence?: number;
    applied?: OffersSnapshot['applied'];
    autoAdd?: OffersSnapshot['autoAdd'];
  };
}

async function fetchOffersQuote(lines: unknown[]) {
  const res = await fetch('/api/offers/quote', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ lines })
  });

  const json = (await res.json()) as OffersQuoteApiResp;

  if (!res.ok || !json?.result) {
    return { discountPence: 0, applied: [], autoAdd: [] } satisfies OffersSnapshot;
  }

  return {
    discountPence: Math.max(0, Math.trunc(json.result.discountTotalPence ?? 0)),
    applied: Array.isArray(json.result.applied) ? json.result.applied : [],
    autoAdd: Array.isArray(json.result.autoAdd) ? json.result.autoAdd : []
  } satisfies OffersSnapshot;
}

export default function CartClient() {
  const { items, updateQty, remove, subtotal, clear } = useCart();

  const [offers, setOffers] = useState<OffersSnapshot>({
    discountPence: 0,
    applied: [],
    autoAdd: []
  });

  const quoteLines = useMemo(
    () =>
      items.map((it) => ({
        productId: (it as unknown as { productId?: string | null }).productId ?? null,
        sku: (it as unknown as { sku?: string | null }).sku ?? null,
        name: it.name,
        unitPricePence: Math.max(0, Math.trunc(it.unitPrice)),
        qty: Math.max(1, Math.trunc(it.quantity)),
        categoryId: (it as unknown as { categoryId?: string | null }).categoryId ?? null,
        tags: (it as unknown as { tags?: string[] | null }).tags ?? null,
        collection: (it as unknown as { collection?: string | null }).collection ?? null
      })),
    [items]
  );

  useEffect(() => {
    let cancelled = false;

    (async () => {
      if (!quoteLines.length) {
        if (!cancelled) setOffers({ discountPence: 0, applied: [], autoAdd: [] });
        return;
      }

      try {
        const snap = await fetchOffersQuote(quoteLines);
        if (!cancelled) setOffers(snap);
      } catch {
        if (!cancelled) setOffers({ discountPence: 0, applied: [], autoAdd: [] });
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [quoteLines]);

  const hasOffersApplied = offers.applied.length > 0;
  const hasOffersAutoAdd = offers.autoAdd.length > 0;
  const hasAnyOffer = hasOffersApplied || hasOffersAutoAdd;

  if (items.length === 0) {
    return (
      <main className={styles.shell}>
        <h1>Basket</h1>
        <p>Your basket is empty.</p>
        <Link className={styles.btn} href="/shop">
          Continue shopping
        </Link>
      </main>
    );
  }

  return (
    <main className={styles.shell}>
      <h1>Basket</h1>

      <div className={styles.grid}>
        <section className={styles.lines}>
          <ul className={styles.list}>
            {items.map((it) => (
              <li key={it.id} className={styles.line}>
                <div className={styles.thumb}>
                  {it.image ? (
                    <Image src={it.image} alt={it.name} width={72} height={72} />
                  ) : (
                    <div className={styles.ph} />
                  )}
                </div>

                <div className={styles.meta}>
                  <div className={styles.name}>{it.name}</div>
                  {(it as unknown as { sku?: string | null }).sku ? (
                    <div className={styles.sku}>
                      {(it as unknown as { sku?: string | null }).sku}
                    </div>
                  ) : null}
                  <div className={styles.price}>{penceToGBP(it.unitPrice)}</div>
                </div>

                <div className={styles.qtyRow}>
                  <button
                    onClick={() => updateQty(it.id, it.quantity - 1)}
                    aria-label="Decrease"
                    disabled={it.quantity <= 1}
                    title={it.quantity <= 1 ? 'Use remove' : 'Decrease'}
                  >
                    <Minus />
                  </button>

                  <span className={styles.qty}>{it.quantity}</span>

                  <button onClick={() => updateQty(it.id, it.quantity + 1)} aria-label="Increase">
                    <Plus />
                  </button>
                </div>

                <div className={styles.lineTotal}>{penceToGBP(it.unitPrice * it.quantity)}</div>

                <button className={styles.remove} onClick={() => remove(it.id)} aria-label="Remove">
                  <Trash2 />
                </button>
              </li>
            ))}
          </ul>

          <button className={styles.clear} onClick={clear}>
            Clear basket
          </button>
        </section>

        <aside className={styles.summary}>
          <h3>Summary</h3>

          <div className={styles.row}>
            <span>Subtotal</span>
            <span>{penceToGBP(subtotal())}</span>
          </div>

          {/* ✅ OFFERS (same style/idea as checkout) */}
          {hasAnyOffer ? (
            <div style={{ marginTop: 8 }}>
              <p className={styles.muted}>
                🎁 Offers available
                {offers.discountPence > 0 ? (
                  <> ({penceToGBP(offers.discountPence)} off)</>
                ) : null} • <strong>Applied</strong>
              </p>

              {hasOffersApplied && (
                <ul className={styles.muted} style={{ margin: '6px 0 6px', paddingLeft: 18 }}>
                  {offers.applied.map((a) => (
                    <li key={`${a.offerId}:${a.kind}`}>
                      {a.name} ({a.kind})
                      {a.discountPence > 0 ? ` — saves ${penceToGBP(a.discountPence)}` : ''}
                    </li>
                  ))}
                </ul>
              )}

              {hasOffersAutoAdd && (
                <ul className={styles.muted} style={{ margin: '6px 0 0', paddingLeft: 18 }}>
                  {offers.autoAdd.map((x, idx) => (
                    <li key={`${x.reasonOfferId}:${idx}`}>
                      Free at checkout: {x.name} × {x.qty}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ) : (
            <p className={styles.muted}>Shipping & taxes calculated at checkout.</p>
          )}

          <Link className={styles.checkout} href="/checkout">
            Checkout
          </Link>
        </aside>
      </div>
    </main>
  );
}
