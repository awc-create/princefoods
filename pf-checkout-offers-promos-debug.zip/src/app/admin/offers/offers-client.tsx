'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import styles from './offers.module.scss';

import CreateOfferModal from '@/components/admin/offers/CreateOfferModal';
import OffersTable from '@/components/admin/offers/OffersTable';
import OffersUsagePanel from '@/components/admin/offers/OffersUsagePanel';

import type { CreateOfferBody, OfferRow, OfferStatus } from '@/components/admin/offers/types';

// ✅ ENGINE types
import type { OfferAdminForm, OfferTargetRule } from '@/types/offers';
import { ruleAllProducts } from '@/types/offers';

interface ApiErr {
  error: string;
}

interface ListOk {
  offers: OfferRow[];
}

interface OneOk {
  offer: OfferRow;
}

interface OfferUsageAttemptRow {
  id: string;
  createdAt: string;

  offerId?: string | null;
  offerName?: string | null;

  outcome: 'APPLIED' | 'REJECTED';
  redeemedOnOrder: boolean;

  email?: string | null;
  userId?: string | null;

  orderId?: string | null;
  orderDisplayId?: string | null;
  orderStatus?: string | null;
  orderPaymentStatus?: string | null;

  discountPence: number;
  shippingDiscountPence: number;

  subtotalPence?: number | null;
  shippingPence?: number | null;

  errorCode?: string | null;
}

interface OfferUsageRedemptionRow {
  id: string;
  createdAt: string;

  offerId: string;
  offerName?: string | null;

  email?: string | null;
  userId?: string | null;

  orderId: string;
  orderDisplayId?: string | null;
  orderStatus?: string | null;
  orderPaymentStatus?: string | null;

  discountPence: number;
  shippingDiscountPence: number;
}

interface OfferUsageApiOk {
  ok: true;
  attempts: OfferUsageAttemptRow[];
  redemptions: OfferUsageRedemptionRow[];
}

function fmtErr(e: unknown, fallback: string) {
  return e instanceof Error ? e.message : fallback;
}

function isListOk(x: ListOk | ApiErr): x is ListOk {
  return typeof x === 'object' && x !== null && 'offers' in x;
}
function isOneOk(x: OneOk | ApiErr): x is OneOk {
  return typeof x === 'object' && x !== null && 'offer' in x;
}

function clampInt(n: number, min: number, max: number) {
  const v = Number.isFinite(n) ? Math.trunc(n) : min;
  return Math.max(min, Math.min(max, v));
}

function buildPool(targetType: CreateOfferBody['targetType']): OfferTargetRule[] {
  // ✅ if you later wire PRODUCT/CATEGORY pickers, this will change.
  if (targetType === 'SITE_WIDE') return [ruleAllProducts()];
  return [ruleAllProducts()];
}

function uiToAdminForm(body: CreateOfferBody): OfferAdminForm {
  const buyQty = clampInt(body.buyQty, 1, 999);
  const pool = buildPool(body.targetType);

  const payload: OfferAdminForm['payload'] =
    body.kind === 'BOGOF'
      ? {
          kind: 'BOGOF',
          data: {
            buyQty,
            getQty: clampInt(body.getQty ?? 1, 1, 999),
            buyPool: pool,
            getPool: pool,
            warnIfGetMoreExpensive: true,
            autoAddGetItem: false
          }
        }
      : body.kind === 'X_FOR_Y'
        ? {
            kind: 'X_FOR_Y',
            data: {
              buyQty,
              payQty: clampInt(body.payQty ?? 1, 1, 999),
              pool
            }
          }
        : {
            kind: 'X_FOR_FIXED_PRICE',
            data: {
              qty: buyQty,
              pricePence: Math.max(0, Math.trunc(body.pricePence ?? 0)),
              pool
            }
          };

  return {
    name: body.name.trim(),
    mode: 'AUTO',
    code: null,
    status: body.status,
    startsAt: body.startsAt,
    endsAt: body.endsAt,
    stackingMode: 'BEST_DISCOUNT_WINS',
    priority: 100,
    maxDiscountPerOrderPence: null,
    preventFreeOrder: true,
    visibility: 'ALL',
    exclusions: {},
    payload
  };
}

export default function OffersClient() {
  const [tab, setTab] = useState<'offers' | 'usage'>('offers');

  // offers list
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [rows, setRows] = useState<OfferRow[]>([]);
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | OfferStatus>('ALL');

  // create modal
  const [open, setOpen] = useState(false);

  // usage
  const [usageLoading, setUsageLoading] = useState(false);
  const [usageErr, setUsageErr] = useState<string | null>(null);
  const [usageDays, setUsageDays] = useState('30');
  const [attempts, setAttempts] = useState<OfferUsageAttemptRow[]>([]);
  const [redemptions, setRedemptions] = useState<OfferUsageRedemptionRow[]>([]);

  const searchRef = useRef<HTMLInputElement | null>(null);

  async function loadOffers() {
    setErr(null);
    setLoading(true);

    try {
      const res = await fetch('/api/admin/offers', { cache: 'no-store' });
      const json = (await res.json()) as ListOk | ApiErr;

      if (!res.ok || !isListOk(json)) {
        setRows([]);
        setErr('error' in json && json.error ? json.error : 'Failed to load offers.');
        return;
      }

      setRows(json.offers ?? []);
    } catch (e) {
      setRows([]);
      setErr(fmtErr(e, 'Failed to load offers.'));
    } finally {
      setLoading(false);
    }
  }

  async function loadUsage() {
    setUsageErr(null);
    setUsageLoading(true);

    try {
      const days = Math.max(1, Math.min(365, Number(usageDays || '30')));
      const res = await fetch(`/api/admin/offers/usage?days=${days}`, { cache: 'no-store' });
      const json = (await res.json()) as OfferUsageApiOk | ApiErr;

      if (!res.ok || !('ok' in json) || (json as OfferUsageApiOk).ok !== true) {
        setUsageErr('error' in json && json.error ? json.error : 'Failed to load usage.');
        setAttempts([]);
        setRedemptions([]);
        return;
      }

      const ok = json as OfferUsageApiOk;
      setAttempts(ok.attempts ?? []);
      setRedemptions(ok.redemptions ?? []);
    } catch (e) {
      setUsageErr(fmtErr(e, 'Failed to load usage.'));
      setAttempts([]);
      setRedemptions([]);
    } finally {
      setUsageLoading(false);
    }
  }

  useEffect(() => {
    void loadOffers();
  }, []);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();

    return rows
      .filter((r) => (statusFilter === 'ALL' ? true : r.status === statusFilter))
      .filter((r) => {
        if (!query) return true;

        const blob = [
          r.name,
          r.kind,
          r.status,
          String(r.buyQty ?? ''),
          String(r.getQty ?? ''),
          String(r.payQty ?? ''),
          String(r.pricePence ?? ''),
          r.targetType,
          String(r.appliedCount ?? '')
        ]
          .join(' ')
          .toLowerCase();

        return blob.includes(query);
      });
  }, [rows, q, statusFilter]);

  async function createOffer(body: CreateOfferBody) {
    setErr(null);

    if (!body.name?.trim()) {
      setErr('Offer name is required.');
      return;
    }

    try {
      const form = uiToAdminForm(body);

      const res = await fetch('/api/admin/offers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });

      const json = (await res.json()) as OneOk | ApiErr;

      if (!res.ok || !isOneOk(json)) {
        setErr('error' in json && json.error ? json.error : 'Failed to create offer.');
        return;
      }

      setOpen(false);
      await loadOffers();
      window.setTimeout(() => searchRef.current?.focus(), 0);
    } catch (e) {
      setErr(fmtErr(e, 'Failed to create offer.'));
    }
  }

  async function toggleOffer(o: OfferRow) {
    setErr(null);

    // optimistic
    setRows((prev) =>
      prev.map((x) =>
        x.id === o.id ? { ...x, status: x.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE' } : x
      )
    );

    try {
      const nextStatus: OfferStatus = o.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';

      const res = await fetch(`/api/admin/offers/${o.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...o, status: nextStatus })
      });

      const json = (await res.json()) as OneOk | ApiErr;

      if (!res.ok || !isOneOk(json)) {
        throw new Error('error' in json && json.error ? json.error : 'Failed to update offer.');
      }

      await loadOffers();
    } catch (e) {
      await loadOffers();
      setErr(fmtErr(e, 'Failed to update offer.'));
    }
  }

  async function deleteOffer(o: OfferRow) {
    const yes = window.confirm(`Delete offer "${o.name}"? This cannot be undone.`);
    if (!yes) return;

    setErr(null);

    try {
      const res = await fetch(`/api/admin/offers/${o.id}`, { method: 'DELETE' });
      const json = (await res.json()) as { ok?: boolean } | ApiErr;

      if (!res.ok || !('ok' in json) || !json.ok) {
        setErr('error' in json && json.error ? json.error : 'Failed to delete offer.');
        return;
      }

      await loadOffers();
    } catch (e) {
      setErr(fmtErr(e, 'Failed to delete offer.'));
    }
  }

  function openModal() {
    setErr(null);
    setOpen(true);
  }

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <div>
          <h1 className={styles.h1}>
            Offers <span className={styles.count}>{rows.length}</span>
          </h1>
          <p className={styles.sub}>
            Automatic deals like BOGOF / X-for-Y / X-for-£ (no coupon code needed).
          </p>
        </div>

        <div className={styles.topActions}>
          <button
            type="button"
            className={styles.secondaryBtn}
            onClick={() => void (tab === 'usage' ? loadUsage() : loadOffers())}
            disabled={tab === 'usage' ? usageLoading : loading}
          >
            Refresh
          </button>

          {tab === 'offers' && (
            <button type="button" className={styles.primaryBtn} onClick={openModal}>
              + New offer
            </button>
          )}
        </div>
      </div>

      <div className={styles.tabs}>
        <button
          type="button"
          className={`${styles.tabBtn} ${tab === 'offers' ? styles.tabActive : ''}`}
          onClick={() => setTab('offers')}
        >
          Offers
        </button>

        <button
          type="button"
          className={`${styles.tabBtn} ${tab === 'usage' ? styles.tabActive : ''}`}
          onClick={() => {
            setTab('usage');
            void loadUsage();
          }}
        >
          Usage
        </button>
      </div>

      {tab === 'offers' && (
        <>
          {err && <div className={styles.bannerError}>{err}</div>}

          <div className={styles.card}>
            <div className={styles.filters}>
              <div className={styles.searchWrap}>
                <input
                  ref={searchRef}
                  className={styles.search}
                  placeholder="Search name/kind/status…"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                />
              </div>

              <select
                className={styles.select}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'ALL' | OfferStatus)}
              >
                <option value="ALL">All statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="PAUSED">Paused</option>
                <option value="EXPIRED">Expired</option>
              </select>
            </div>

            <div className={styles.tableWrap}>
              {loading ? (
                <div className={styles.mutedCell}>Loading…</div>
              ) : filtered.length === 0 ? (
                <div className={styles.mutedCell}>No offers found.</div>
              ) : (
                <OffersTable
                  rows={filtered}
                  onEdit={() => setErr('Edit UI not wired yet.')}
                  onToggle={(o) => void toggleOffer(o)}
                  onDelete={(o) => void deleteOffer(o)}
                />
              )}
            </div>
          </div>

          <CreateOfferModal open={open} onClose={() => setOpen(false)} onCreate={createOffer} />
        </>
      )}

      {tab === 'usage' && (
        <OffersUsagePanel
          loading={usageLoading}
          error={usageErr}
          days={usageDays}
          setDays={setUsageDays}
          onReload={loadUsage}
          attempts={attempts}
          redemptions={redemptions}
        />
      )}
    </div>
  );
}
