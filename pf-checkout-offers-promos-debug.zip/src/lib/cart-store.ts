// src/lib/cart-store.ts
'use client';

import { create, type StateCreator } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CartLine {
  id: string; // unique line id (sku or productId+variant)
  sku?: string | null;
  productId?: string | null;
  name: string;
  image?: string | null;
  unitPrice: number; // pence
  quantity: number;
  imageUrl?: string;
}

export interface CartState {
  items: CartLine[];
  isOpen: boolean;
  open: () => void;
  close: () => void;
  toggle: () => void;
  add: (line: Omit<CartLine, 'quantity'> & { quantity?: number }) => void;
  updateQty: (id: string, qty: number) => void;
  remove: (id: string) => void;
  clear: () => void;
  subtotal: () => number;
  count: () => number;
}

/* ---------------- helpers ---------------- */

const normStr = (v: unknown) => {
  if (typeof v !== 'string') return '';
  return v.trim();
};

const normSku = (v: unknown): string | null => {
  const s = normStr(v);
  if (!s) return null;
  return s.replace(/\s+/g, ' ');
};

const normProductId = (v: unknown): string | null => {
  const s = normStr(v);
  if (!s) return null;
  return s;
};

const normName = (v: unknown) => {
  const s = normStr(v);
  return s.replace(/\s+/g, ' ');
};

// Stable line id (this is CRITICAL for offers + qty merging)
function buildLineId(input: {
  sku?: string | null;
  productId?: string | null;
  name: string;
  unitPrice: number;
}) {
  const sku = normSku(input.sku);
  if (sku) return `sku:${sku}`;

  const pid = normProductId(input.productId);
  if (pid) return `pid:${pid}`;

  // last-resort fallback (still stable-ish)
  const nm = normName(input.name).toLowerCase();
  const price = Math.max(0, Math.trunc(input.unitPrice));
  return `name:${nm}|p:${price}`;
}

function normaliseLine(raw: Partial<CartLine>): CartLine | null {
  const name = normName(raw.name ?? '');
  const unitPrice = Math.max(0, Math.trunc(Number(raw.unitPrice ?? 0)));
  const quantity = Math.max(1, Math.trunc(Number(raw.quantity ?? 1)));

  if (!name) return null;

  const sku = normSku(raw.sku);
  const productId = normProductId(raw.productId);

  const id = normStr(raw.id) || buildLineId({ sku, productId, name, unitPrice });

  return {
    id,
    sku,
    productId,
    name,
    image: (raw.image ?? null) as string | null,
    imageUrl: (raw.imageUrl ?? undefined) as string | undefined,
    unitPrice,
    quantity
  };
}

function mergeDuplicateLines(lines: CartLine[]) {
  const map = new Map<string, CartLine>();

  for (const l of lines) {
    const prev = map.get(l.id);
    if (!prev) {
      map.set(l.id, { ...l });
      continue;
    }

    prev.quantity += l.quantity;

    if (!prev.sku && l.sku) prev.sku = l.sku;
    if (!prev.productId && l.productId) prev.productId = l.productId;
    if (!prev.image && l.image) prev.image = l.image;
    if (!prev.imageUrl && l.imageUrl) prev.imageUrl = l.imageUrl;
  }

  return Array.from(map.values());
}

/* ---------------- store ---------------- */

const creator: StateCreator<CartState> = (set, get) => ({
  items: [],
  isOpen: false,
  open: () => set({ isOpen: true }),
  close: () => set({ isOpen: false }),
  toggle: () => set({ isOpen: !get().isOpen }),

  add: (line: Omit<CartLine, 'quantity'> & { quantity?: number }) =>
    set((s) => {
      const qty = Math.max(1, Math.trunc(line.quantity ?? 1));

      const normalised = normaliseLine({
        ...line,
        quantity: qty
      });

      if (!normalised) return { ...s };

      const idx = s.items.findIndex((i) => i.id === normalised.id);

      if (idx >= 0) {
        const next = [...s.items];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + qty };

        if (!next[idx].sku && normalised.sku) next[idx].sku = normalised.sku;
        if (!next[idx].productId && normalised.productId)
          next[idx].productId = normalised.productId;
        if (!next[idx].image && normalised.image) next[idx].image = normalised.image;
        if (!next[idx].imageUrl && normalised.imageUrl) next[idx].imageUrl = normalised.imageUrl;

        return { items: next, isOpen: true };
      }

      return { items: [...s.items, normalised], isOpen: true };
    }),

  updateQty: (id: string, qty: number) =>
    set((s) => {
      const next = s.items
        .map((i) =>
          i.id === id ? ({ ...i, quantity: Math.max(1, Math.trunc(qty)) } as CartLine) : i
        )
        .filter((i) => i.quantity > 0);
      return { items: next };
    }),

  remove: (id: string) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),

  clear: () => set({ items: [] }),

  subtotal: () => get().items.reduce<number>((sum, i) => sum + i.unitPrice * i.quantity, 0),

  count: () => get().items.reduce<number>((n, i) => n + i.quantity, 0)
});

export const useCart = create<CartState>()(
  persist(creator, {
    name: 'pf-cart-v1',
    version: 2,

    migrate: (persisted, _version) => {
      const state = persisted as Partial<CartState> | undefined;

      // If nothing saved yet, return persisted slice (not full CartState)
      if (!state || typeof state !== 'object') {
        return { items: [], isOpen: false };
      }

      const rawItems = Array.isArray(state.items) ? state.items : [];
      const fixed = rawItems
        .map((x) => normaliseLine(x as Partial<CartLine>))
        .filter((x): x is CartLine => Boolean(x));

      const merged = mergeDuplicateLines(fixed);

      return {
        items: merged,
        isOpen: Boolean(state.isOpen)
      };
    }
  })
);
