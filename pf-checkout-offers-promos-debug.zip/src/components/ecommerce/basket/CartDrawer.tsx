// src/components/cart/CartDrawer.tsx
'use client';

import { useCart } from '@/lib/cart-store';
import { penceToGBP } from '@/lib/money';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import styles from './CartDrawer.module.scss';

interface OffersSnapshot {
  discountPence: number;
  applied: { offerId: string; name: string; kind: string; discountPence: number }[];
  autoAdd: { reasonOfferId: string; name: string; qty: number }[];
}

interface OffersQuoteApiResp {
  result?: {
    discountTotalPence?: number;
    applied?: OffersSnapshot['applied'];
    autoAdd?: OffersSnapshot['autoAdd'];
  };
}

async function fetchOffersQuote(lines: unknown[]) {
  const res = await fetch('/api/offers/quote', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ lines })
  });

  const json = (await res.json()) as OffersQuoteApiResp;

  if (!res.ok || !json?.result) {
    return { discountPence: 0, applied: [], autoAdd: [] } satisfies OffersSnapshot;
  }

  return {
    discountPence: Math.max(0, Math.trunc(json.result.discountTotalPence ?? 0)),
    applied: Array.isArray(json.result.applied) ? json.result.applied : [],
    autoAdd: Array.isArray(json.result.autoAdd) ? json.result.autoAdd : []
  } satisfies OffersSnapshot;
}

export default function CartDrawer() {
  const { items, isOpen, toggle, updateQty, remove, subtotal } = useCart();

  const [offers, setOffers] = useState<OffersSnapshot>({
    discountPence: 0,
    applied: [],
    autoAdd: []
  });

  const quoteLines = useMemo(
    () =>
      items.map((it) => ({
        productId: (it as unknown as { productId?: string | null }).productId ?? null,
        sku: (it as unknown as { sku?: string | null }).sku ?? null,
        name: it.name,
        unitPricePence: Math.max(0, Math.trunc(it.unitPrice)),
        qty: Math.max(1, Math.trunc(it.quantity))
      })),
    [items]
  );

  useEffect(() => {
    let cancelled = false;

    (async () => {
      if (!isOpen) return;

      if (!quoteLines.length) {
        if (!cancelled) setOffers({ discountPence: 0, applied: [], autoAdd: [] });
        return;
      }

      try {
        const snap = await fetchOffersQuote(quoteLines);
        if (!cancelled) setOffers(snap);
      } catch {
        if (!cancelled) setOffers({ discountPence: 0, applied: [], autoAdd: [] });
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isOpen, quoteLines]);

  const hasOffersApplied = offers.applied.length > 0;
  const hasOffersAutoAdd = offers.autoAdd.length > 0;
  const hasAnyOffer = hasOffersApplied || hasOffersAutoAdd;

  if (!isOpen) return null;

  return (
    <aside className={styles.host} aria-modal="true" role="dialog" aria-label="Basket">
      <div className={styles.backdrop} onClick={toggle} />
      <div className={styles.panel}>
        <header className={styles.header}>
          <h3>Basket</h3>
          <button onClick={toggle} aria-label="Close basket">
            ×
          </button>
        </header>

        <ul className={styles.list}>
          {items.map((it) => (
            <li key={it.id} className={styles.line}>
              <div className={styles.thumb}>
                {it.image ? (
                  <Image src={it.image} alt={it.name} width={56} height={56} />
                ) : (
                  <div className={styles.ph} />
                )}
              </div>

              <div className={styles.meta}>
                <div className={styles.name} title={it.name}>
                  {it.name}
                </div>
                {(it as unknown as { sku?: string | null }).sku ? (
                  <div className={styles.sku}>{(it as unknown as { sku?: string | null }).sku}</div>
                ) : null}
                <div className={styles.unit}>{penceToGBP(it.unitPrice)}</div>
              </div>

              <div className={styles.qtyRow}>
                <button onClick={() => updateQty(it.id, it.quantity - 1)} aria-label="Decrease">
                  −
                </button>
                <span className={styles.qty}>{it.quantity}</span>
                <button onClick={() => updateQty(it.id, it.quantity + 1)} aria-label="Increase">
                  +
                </button>
              </div>

              <div className={styles.lineTotal}>{penceToGBP(it.unitPrice * it.quantity)}</div>

              <button className={styles.remove} onClick={() => remove(it.id)} aria-label="Remove">
                ×
              </button>
            </li>
          ))}

          {items.length === 0 && <li className={styles.empty}>Your basket is empty.</li>}
        </ul>

        <div className={styles.summary}>
          <span>Subtotal</span>
          <strong>{penceToGBP(subtotal())}</strong>
        </div>

        {/* ✅ OFFERS (same data source as checkout: /api/offers/quote -> {result:{...}}) */}
        {hasAnyOffer && (
          <div style={{ padding: '0 16px 12px', color: '#6b7280', fontSize: 12 }}>
            🎁 Offers available
            {offers.discountPence > 0 ? (
              <> ({penceToGBP(offers.discountPence)} off)</>
            ) : null} • <strong>Applied</strong>
          </div>
        )}

        <footer className={styles.footer}>
          <Link href="/cart" onClick={toggle} className={styles.linkBtn}>
            View basket
          </Link>
          <Link href="/checkout" onClick={toggle} className={styles.primaryBtn}>
            Checkout
          </Link>
        </footer>
      </div>
    </aside>
  );
}
