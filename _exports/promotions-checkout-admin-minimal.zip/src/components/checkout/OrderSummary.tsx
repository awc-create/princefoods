// src/components/checkout/OrderSummary.tsx
'use client';

import styles from '@/app/checkout/checkout.module.scss';
import type { CartLine } from '@/lib/cart-store';
import { penceToGBP } from '@/lib/money';
import { useMemo, useState } from 'react';

type ShippingKind = 'DRY' | 'FROZEN' | 'MIXED';

interface EvalItem {
  productId?: string | null;
  sku?: string | null;
  unitPrice: number; // pence
  quantity: number;
}

interface EvaluateOk {
  ok: true;
  currency: string;
  promotionId: string;
  code: string;
  name: string;
  discountPence: number;
  shippingDiscountPence: number;
}

interface EvaluateErr {
  ok: false;
  error: string;
}
type EvaluateResp = EvaluateOk | EvaluateErr;

function normCode(v: string) {
  return v.trim().toUpperCase().replace(/\s+/g, '');
}

function friendlyPromoError(code: string) {
  switch (code) {
    case 'CODE_REQUIRED':
      return 'Enter a promo code.';
    case 'INVALID_CODE':
      return 'That code is not recognised.';
    case 'PROMO_NOT_ACTIVE':
      return 'This promo is not active.';
    case 'PROMO_NOT_STARTED':
      return 'This promo is not valid yet.';
    case 'PROMO_EXPIRED':
      return 'This promo has expired.';
    case 'PROMO_LOCKED_TO_USER':
    case 'PROMO_LOCKED_TO_EMAIL':
      return 'This code is not eligible for this customer.';
    case 'PROMO_MAX_USES_REACHED':
      return 'This code has reached its usage limit.';
    case 'PROMO_MAX_USES_PER_USER_REACHED':
    case 'PROMO_MAX_USES_PER_EMAIL_REACHED':
      return 'This code has already been used.';
    case 'NO_ITEMS':
      return 'Your cart is empty.';
    default:
      return code || 'Promo could not be applied.';
  }
}

export default function OrderSummary({
  mounted,
  items,
  liveSubtotal,
  shippingCost,
  grand,
  onDecQty,
  onIncQty,
  onSetQty,
  onRemove,
  promo,
  setPromo,

  // ✅ NEW: optional identity + callback so checkout can “lock in” the promo for place-order
  userId,
  email,
  currency = 'GBP',
  shippingKind = 'DRY',
  onPromoApplied
}: {
  mounted: boolean;
  items: CartLine[];
  liveSubtotal: number;
  shippingCost: number;
  grand: number;
  onDecQty: (id: string) => void;
  onIncQty: (id: string) => void;
  onSetQty: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  promo: string;
  setPromo: (v: string) => void;

  userId?: string | null;
  email?: string | null;
  currency?: string;
  shippingKind?: ShippingKind;

  onPromoApplied?: (v: {
    promotionId: string | null;
    promotionCode: string | null;
    promoName?: string | null;
    discountPence: number;
    shippingDiscountPence: number;
  }) => void;
}) {
  const [promoState, setPromoState] = useState<
    | { status: 'idle' }
    | { status: 'checking' }
    | {
        status: 'applied';
        promotionId: string;
        code: string;
        name: string;
        discountPence: number;
        shippingDiscountPence: number;
      }
    | { status: 'error'; message: string }
  >({ status: 'idle' });

  const promoDiscountTotal = useMemo(() => {
    if (promoState.status !== 'applied') return 0;
    return Math.max(0, promoState.discountPence + promoState.shippingDiscountPence);
  }, [promoState]);

  async function applyPromoNow() {
    const code = normCode(promo);
    if (!code) {
      setPromoState({ status: 'error', message: 'Enter a promo code.' });
      onPromoApplied?.({
        promotionId: null,
        promotionCode: null,
        promoName: null,
        discountPence: 0,
        shippingDiscountPence: 0
      });
      return;
    }

    const evalItems: EvalItem[] = items.map((it) => ({
      productId: it.productId ?? null,
      sku: (it as unknown as { sku?: string | null }).sku ?? null,
      unitPrice: Math.max(0, Math.trunc(it.unitPrice)),
      quantity: Math.max(1, Math.trunc(it.quantity))
    }));

    setPromoState({ status: 'checking' });

    try {
      const res = await fetch('/api/promotions/evaluate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          code,
          items: evalItems,
          userId: userId ?? null,
          email: email ?? null,
          subtotalPence: Math.max(0, Math.trunc(liveSubtotal)),
          shippingPence: Math.max(0, Math.trunc(shippingCost)),
          currency,
          shippingKind
        })
      });

      const data = (await res.json()) as EvaluateResp;

      if (!data || data.ok !== true) {
        const err = (data as EvaluateErr | null)?.error ?? 'Promo could not be applied.';
        const msg = friendlyPromoError(err);
        setPromoState({ status: 'error', message: msg });
        onPromoApplied?.({
          promotionId: null,
          promotionCode: null,
          promoName: null,
          discountPence: 0,
          shippingDiscountPence: 0
        });
        return;
      }

      setPromoState({
        status: 'applied',
        promotionId: data.promotionId,
        code: data.code,
        name: data.name,
        discountPence: Math.max(0, Math.trunc(data.discountPence)),
        shippingDiscountPence: Math.max(0, Math.trunc(data.shippingDiscountPence))
      });

      onPromoApplied?.({
        promotionId: data.promotionId,
        promotionCode: data.code,
        promoName: data.name,
        discountPence: Math.max(0, Math.trunc(data.discountPence)),
        shippingDiscountPence: Math.max(0, Math.trunc(data.shippingDiscountPence))
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Promo check failed.';
      setPromoState({ status: 'error', message: msg });
      onPromoApplied?.({
        promotionId: null,
        promotionCode: null,
        promoName: null,
        discountPence: 0,
        shippingDiscountPence: 0
      });
    }
  }

  function clearPromo() {
    setPromo('');
    setPromoState({ status: 'idle' });
    onPromoApplied?.({
      promotionId: null,
      promotionCode: null,
      promoName: null,
      discountPence: 0,
      shippingDiscountPence: 0
    });
  }

  return (
    <aside className={styles.summary} aria-label="Order summary">
      <h3 className={styles.h3}>Summary</h3>

      <ul className={styles.items}>
        {!mounted && <li className={styles.muted}>Loading cart…</li>}
        {mounted && items.length === 0 && <li className={styles.muted}>Your cart is empty.</li>}

        {mounted &&
          items.map((it) => (
            <li key={it.id} className={styles.itemRow}>
              <div className={styles.itemLeft}>
                <div className={styles.thumbWrap} aria-hidden>
                  <img
                    src={it.imageUrl ?? it.image ?? '/assets/prince-foods-logo.png'}
                    alt={it.name}
                    className={styles.thumb}
                    loading="lazy"
                    decoding="async"
                  />
                </div>

                <div className={styles.itemMeta}>
                  <span className={styles.itemName} title={it.name}>
                    {it.name}
                  </span>

                  <div className={styles.qtyControls} aria-label="Quantity controls">
                    <button
                      type="button"
                      onClick={() => (it.quantity > 1 ? onDecQty(it.id) : onRemove(it.id))}
                      className={styles.qtyBtn}
                      aria-label="Decrease quantity"
                    >
                      −
                    </button>

                    <input
                      className={styles.qtyInput}
                      inputMode="numeric"
                      value={it.quantity}
                      onChange={(e) => {
                        const v = Math.max(1, parseInt(e.target.value || '1', 10));
                        onSetQty(it.id, v);
                      }}
                      aria-label="Quantity"
                    />

                    <button
                      type="button"
                      onClick={() => onIncQty(it.id)}
                      className={styles.qtyBtn}
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              <div className={styles.itemPrice}>{penceToGBP(it.unitPrice * it.quantity)}</div>
            </li>
          ))}
      </ul>

      <div className={styles.promoRow}>
        <input
          className={styles.promoInput}
          placeholder="Promo code"
          value={promo}
          onChange={(e) => setPromo(e.target.value)}
        />

        {promoState.status === 'applied' ? (
          <button
            type="button"
            className={styles.promoBtn}
            onClick={clearPromo}
            title="Remove promo"
          >
            Remove
          </button>
        ) : (
          <button
            type="button"
            className={styles.promoBtn}
            onClick={applyPromoNow}
            disabled={promoState.status === 'checking'}
            title="Apply promo"
          >
            {promoState.status === 'checking' ? 'Checking…' : 'Apply'}
          </button>
        )}
      </div>

      {promoState.status === 'applied' && (
        <p className={styles.promoHint}>
          ✅ Applied: <strong>{promoState.code}</strong> ({penceToGBP(promoDiscountTotal)} off)
        </p>
      )}

      {promoState.status === 'error' && (
        <p className={styles.promoHint} style={{ color: '#ef4444' }}>
          {promoState.message}
        </p>
      )}

      <div className={styles.row}>
        <span>Subtotal</span>
        <span>{penceToGBP(liveSubtotal)}</span>
      </div>

      <div className={styles.row}>
        <span>Shipping</span>
        <span>{penceToGBP(shippingCost)}</span>
      </div>

      {promoState.status === 'applied' && promoDiscountTotal > 0 && (
        <div className={styles.row}>
          <span>Promotion ({promoState.code})</span>
          <span>-{penceToGBP(promoDiscountTotal)}</span>
        </div>
      )}

      <div className={styles.total}>
        <span>Total</span>
        <strong>{penceToGBP(grand)}</strong>
      </div>
    </aside>
  );
}
