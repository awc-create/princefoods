// src/components/checkout/PaymentStep.tsx
'use client';

import styles from '@/app/checkout/checkout.module.scss';
import { penceToGBP } from '@/lib/money';
import type { Delivery } from './types';

export default function PaymentStep({
  delivery,
  setDelivery,
  placing,
  formValid,
  mounted,
  err,
  onEditAddress,
  onPlaceOrder,
  isAdmin,
  onPayWithStripe,
  onPlaceTestOrder
}: {
  delivery: Delivery;
  setDelivery: (d: Delivery) => void;
  placing: boolean;
  formValid: boolean;
  mounted: boolean;
  err: string | null;
  onEditAddress: () => void;
  onPlaceOrder: () => void;
  isAdmin: boolean;
  onPayWithStripe: () => void;
  onPlaceTestOrder: () => void;
}) {
  return (
    <>
      <div className={styles.paymentHeader}>
        <h3 className={styles.h3} style={{ marginTop: 0 }}>
          Delivery & payment
        </h3>
        <button type="button" className={styles.backBtn} onClick={onEditAddress}>
          Edit address
        </button>
      </div>

      <div className={styles.deliveryWrap} role="group" aria-label="Delivery method">
        <span className={styles.deliveryLabel}>Delivery</span>

        <div className={styles.deliveryOptions}>
          <label className={styles.radio}>
            <input
              type="radio"
              name="delivery"
              value="standard"
              checked={delivery === 'standard'}
              onChange={(e) => e.target.checked && setDelivery('standard')}
            />
            <span>Standard (2–4 days) — {penceToGBP(399)}</span>
          </label>

          <label className={styles.radio}>
            <input
              type="radio"
              name="delivery"
              value="express"
              checked={delivery === 'express'}
              onChange={(e) => e.target.checked && setDelivery('express')}
            />
            <span>Express (Next day) — {penceToGBP(799)}</span>
          </label>
        </div>
      </div>

      {err && (
        <p className={styles.err} role="alert" aria-live="polite">
          {err}
        </p>
      )}

      <div className={styles.stepActions}>
        <button
          className={styles.place}
          disabled={placing || (mounted ? !formValid : true)}
          onClick={onPlaceOrder}
          aria-disabled={placing || (mounted ? !formValid : true)}
        >
          {placing ? 'Placing…' : 'Place order'}
        </button>

        <p className={styles.muted}>
          You’ll be charged on the next step when a real PSP is connected.
        </p>

        {isAdmin && (
          <button
            type="button"
            className={styles.testBtn}
            onClick={onPayWithStripe}
            disabled={placing || (mounted ? !formValid : true)}
            aria-disabled={placing || (mounted ? !formValid : true)}
            title="Creates the order, then redirects to Stripe Checkout (test)."
          >
            Pay with Stripe (test)
          </button>
        )}

        {isAdmin && (
          <button
            type="button"
            className={styles.testBtn}
            onClick={onPlaceTestOrder}
            disabled={placing || !formValid}
            aria-disabled={placing || !formValid}
            title="Admin-only: writes a paid test order directly."
            style={{ marginTop: 8 }}
          >
            Place Test Order (admin only)
          </button>
        )}
      </div>
    </>
  );
}
