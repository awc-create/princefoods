'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import styles from './promotions.module.scss';

type PromotionStatus = 'ACTIVE' | 'PAUSED' | 'EXPIRED';
type PromotionType = 'CODE' | 'GIFT';
type DiscountType = 'PERCENT' | 'AMOUNT' | 'PRODUCT_100';
type TargetType = 'SITE_WIDE' | 'CATEGORIES' | 'PRODUCTS';

type PromoKindUI = 'AMOUNT_OFF' | 'PERCENT_OFF' | 'FREE_SHIPPING';

interface PromotionRow {
  id: string;
  name: string;
  code: string;
  type: PromotionType;
  status: PromotionStatus;

  discountType: DiscountType;
  percentOff: number | null;
  amountOffPence: number | null;

  applyShippingDiscount: boolean;
  shippingPercentOffDry: number | null;
  shippingPercentOffFrozen: number | null;

  targetType: TargetType;

  startsAt: string | null;
  endsAt: string | null;
  maxUsesTotal: number | null;
  maxUsesPerUser: number | null;

  createdAt: string;
}

interface ApiListOk {
  ok: true;
  promotions: PromotionRow[];
}
interface ApiErr {
  ok: false;
  error: string;
}

interface CreateBody {
  name: string;
  code: string;
  type: PromotionType;
  status: PromotionStatus;
  startsAt: string | null;
  endsAt: string | null;

  maxUsesTotal: number | null;
  maxUsesPerUser: number | null;

  targetType: TargetType;

  discountType: DiscountType;
  percentOff?: number | null;
  amountOffPence?: number | null;

  applyShippingDiscount?: boolean;
  shippingPercentOffDry?: number | null;
  shippingPercentOffFrozen?: number | null;

  categoryIds?: string[];
  productIds?: string[];
}

function normCode(raw: string) {
  return raw.trim().toUpperCase().replace(/\s+/g, '');
}

function fmtDate(d: string | null) {
  if (!d) return '—';
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString();
}

function clampInt(n: number, min: number, max: number) {
  const x = Math.trunc(n);
  return Math.max(min, Math.min(max, x));
}

function poundsToPence(raw: string): number | null {
  const t = raw.trim();
  if (!t) return null;
  const x = Number(t);
  if (!Number.isFinite(x) || x < 0) return null;
  return Math.round(x * 100);
}

function toIntOrNull(raw: string): number | null {
  const t = raw.trim();
  if (!t) return null;
  const x = Number(t);
  if (!Number.isFinite(x)) return null;
  return Math.trunc(x);
}

function discountLabel(p: PromotionRow) {
  if (p.discountType === 'PERCENT') return `${p.percentOff ?? 0}% OFF`;
  if (p.discountType === 'AMOUNT') return `£${((p.amountOffPence ?? 0) / 100).toFixed(2)} OFF`;
  if (p.discountType === 'PRODUCT_100') return `100% OFF`;
  return '—';
}

function targetLabel(p: PromotionRow) {
  if (p.targetType === 'SITE_WIDE') return 'All products';
  if (p.targetType === 'CATEGORIES') return 'Categories';
  if (p.targetType === 'PRODUCTS') return 'Products';
  return '—';
}

function statusPillClass(s: PromotionStatus) {
  if (s === 'ACTIVE') return styles.pillActive;
  if (s === 'PAUSED') return styles.pillPaused;
  return styles.pillExpired;
}

function kindToDiscountType(kind: PromoKindUI): DiscountType {
  if (kind === 'PERCENT_OFF') return 'PERCENT';
  if (kind === 'AMOUNT_OFF') return 'AMOUNT';
  // FREE_SHIPPING uses no item discount by default
  return 'AMOUNT';
}

export default function PromotionsClient() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [rows, setRows] = useState<PromotionRow[]>([]);
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | PromotionStatus>('ALL');

  const [open, setOpen] = useState(false);

  // modal state
  const [promoKind, setPromoKind] = useState<PromoKindUI>('AMOUNT_OFF');
  const [code, setCode] = useState('');
  const [name, setName] = useState('');

  const [targetType, setTargetType] = useState<TargetType>('SITE_WIDE');

  const [discountValue, setDiscountValue] = useState(''); // pounds or percent depending on kind

  const [applyShipping, setApplyShipping] = useState(false);
  const [shippingPct, setShippingPct] = useState('100');

  const [startsAt, setStartsAt] = useState(''); // yyyy-mm-dd
  const [endsAt, setEndsAt] = useState(''); // yyyy-mm-dd
  const [noEnd, setNoEnd] = useState(true);

  const [limitTotal, setLimitTotal] = useState(false);
  const [maxUsesTotal, setMaxUsesTotal] = useState('');
  const [limitPerCustomer, setLimitPerCustomer] = useState(false);

  const [saving, setSaving] = useState(false);

  const dialogBodyRef = useRef<HTMLDivElement | null>(null);

  async function load() {
    setErr(null);
    setLoading(true);
    try {
      const res = await fetch('/api/admin/promotions', { cache: 'no-store' });
      const json = (await res.json()) as ApiListOk | ApiErr;

      if (!res.ok || !json.ok) {
        setErr((json as ApiErr).error ?? 'Failed to load promotions.');
        setRows([]);
        return;
      }

      setRows((json as ApiListOk).promotions ?? []);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to load promotions.');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();

    return rows
      .filter((r) => (statusFilter === 'ALL' ? true : r.status === statusFilter))
      .filter((r) => {
        if (!query) return true;
        const blob = [
          r.name,
          r.code,
          r.status,
          r.type,
          r.discountType,
          targetLabel(r),
          discountLabel(r)
        ]
          .join(' ')
          .toLowerCase();
        return blob.includes(query);
      });
  }, [rows, q, statusFilter]);

  function resetModal() {
    setPromoKind('AMOUNT_OFF');
    setCode('');
    setName('');
    setTargetType('SITE_WIDE');
    setDiscountValue('');
    setApplyShipping(false);
    setShippingPct('100');
    setStartsAt('');
    setEndsAt('');
    setNoEnd(true);
    setLimitTotal(false);
    setMaxUsesTotal('');
    setLimitPerCustomer(false);
    setErr(null);
  }

  function openModal() {
    resetModal();
    setOpen(true);
    window.setTimeout(() => {
      dialogBodyRef.current?.scrollTo({ top: 0 });
    }, 0);
  }

  function closeModal() {
    setOpen(false);
  }

  // If user selects Free shipping, auto enable shipping discount 100% and disable item discount
  useEffect(() => {
    if (promoKind === 'FREE_SHIPPING') {
      setApplyShipping(true);
      setShippingPct('100');
      setDiscountValue('');
    }
  }, [promoKind]);

  async function createPromo() {
    setErr(null);

    const c = normCode(code);
    const n = name.trim();

    if (!c) return setErr('Promo code is required.');
    if (!n) return setErr('Promo name is required.');

    const kindDiscountType = kindToDiscountType(promoKind);

    let percentOff: number | null | undefined = undefined;
    let amountOffPence: number | null | undefined = undefined;

    if (promoKind === 'PERCENT_OFF') {
      const pct = toIntOrNull(discountValue);
      if (pct == null) return setErr('Enter a valid percent.');
      percentOff = clampInt(pct, 0, 100);
      amountOffPence = undefined;
    } else if (promoKind === 'AMOUNT_OFF') {
      const pence = poundsToPence(discountValue);
      if (pence == null) return setErr('Enter a valid amount.');
      amountOffPence = Math.max(0, pence);
      percentOff = undefined;
    } else {
      // FREE_SHIPPING => no item discount by default
      amountOffPence = 0;
      percentOff = undefined;
    }

    const shipPctInt = toIntOrNull(shippingPct);
    const shipPctClamped = shipPctInt == null ? 0 : clampInt(shipPctInt, 0, 100);

    const body: CreateBody = {
      name: n,
      code: c,
      type: 'CODE',
      status: 'ACTIVE',
      startsAt: startsAt ? new Date(startsAt).toISOString() : null,
      endsAt: noEnd ? null : endsAt ? new Date(endsAt).toISOString() : null,

      maxUsesTotal: limitTotal ? toIntOrNull(maxUsesTotal) : null,
      maxUsesPerUser: limitPerCustomer ? 1 : null,

      targetType,

      discountType: kindDiscountType,
      ...(percentOff !== undefined ? { percentOff } : {}),
      ...(amountOffPence !== undefined ? { amountOffPence } : {}),

      applyShippingDiscount: applyShipping || promoKind === 'FREE_SHIPPING',
      shippingPercentOffDry: applyShipping || promoKind === 'FREE_SHIPPING' ? shipPctClamped : null,
      shippingPercentOffFrozen:
        applyShipping || promoKind === 'FREE_SHIPPING' ? shipPctClamped : null,

      // NOTE: categories/products selection UI later
      categoryIds: [],
      productIds: []
    };

    setSaving(true);
    try {
      const res = await fetch('/api/admin/promotions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const json = (await res.json()) as { ok: boolean; error?: string };

      if (!res.ok || !json.ok) {
        setErr(json.error ?? 'Failed to create promotion.');
        return;
      }

      closeModal();
      await load();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to create promotion.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <div>
          <h1 className={styles.h1}>
            Promotions <span className={styles.count}>{rows.length}</span>
          </h1>
          <p className={styles.sub}>Create promo codes to use in checkout.</p>
        </div>

        <div className={styles.topActions}>
          <button type="button" className={styles.secondaryBtn} onClick={load} disabled={loading}>
            Refresh
          </button>
          <button type="button" className={styles.primaryBtn} onClick={openModal}>
            + New promo
          </button>
        </div>
      </div>

      {err && <div className={styles.bannerError}>{err}</div>}

      <div className={styles.card}>
        <div className={styles.filters}>
          <div className={styles.searchWrap}>
            <input
              className={styles.search}
              placeholder="Search name/code/target/discount…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>

          <select
            className={styles.select}
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'ALL' | PromotionStatus)}
          >
            <option value="ALL">All statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="PAUSED">Paused</option>
            <option value="EXPIRED">Expired</option>
          </select>
        </div>

        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Discount</th>
                <th>Type</th>
                <th>Code</th>
                <th>Status</th>
                <th>Window</th>
                <th>Target</th>
              </tr>
            </thead>

            <tbody>
              {loading && (
                <tr>
                  <td colSpan={7} className={styles.mutedCell}>
                    Loading…
                  </td>
                </tr>
              )}

              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className={styles.mutedCell}>
                    No promotions found.
                  </td>
                </tr>
              )}

              {!loading &&
                filtered.map((p) => (
                  <tr key={p.id}>
                    <td className={styles.nameCell}>
                      <div className={styles.nameMain}>{p.name}</div>
                      <div className={styles.nameSub}>Created {fmtDate(p.createdAt)}</div>
                    </td>

                    <td>
                      <div className={styles.cellMain}>{discountLabel(p)}</div>
                      {p.applyShippingDiscount && (
                        <div className={styles.cellSub}>
                          + Shipping {p.shippingPercentOffDry ?? 0}% off
                        </div>
                      )}
                    </td>

                    <td>
                      <div className={styles.cellMain}>{p.type}</div>
                      <div className={styles.cellSub}>{p.discountType}</div>
                    </td>

                    <td className={styles.codeCell}>{p.code}</td>

                    <td>
                      <span className={`${styles.pill} ${statusPillClass(p.status)}`}>
                        {p.status}
                      </span>
                    </td>

                    <td>
                      <div className={styles.cellMain}>
                        {p.startsAt ? fmtDate(p.startsAt) : 'Any time'}
                      </div>
                      <div className={styles.cellSub}>
                        {p.endsAt ? fmtDate(p.endsAt) : 'No end'}
                      </div>
                    </td>

                    <td>
                      <div className={styles.cellMain}>{targetLabel(p)}</div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* =========================
          Modal
          ========================= */}
      {open && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <div>
                <div className={styles.modalTitle}>New promotion</div>
                <div className={styles.modalSub}>Choose a promo type and configure the code.</div>
              </div>

              <button
                type="button"
                className={styles.iconBtn}
                onClick={closeModal}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className={styles.modalBody} ref={dialogBodyRef}>
              <div className={styles.kindRow}>
                <button
                  type="button"
                  className={`${styles.kindCard} ${promoKind === 'AMOUNT_OFF' ? styles.kindActive : ''}`}
                  onClick={() => setPromoKind('AMOUNT_OFF')}
                >
                  <div className={styles.kindIcon}>£</div>
                  <div>
                    <div className={styles.kindTitle}>Amount off</div>
                    <div className={styles.kindSub}>£ discount</div>
                  </div>
                </button>

                <button
                  type="button"
                  className={`${styles.kindCard} ${promoKind === 'PERCENT_OFF' ? styles.kindActive : ''}`}
                  onClick={() => setPromoKind('PERCENT_OFF')}
                >
                  <div className={styles.kindIcon}>%</div>
                  <div>
                    <div className={styles.kindTitle}>Percent off</div>
                    <div className={styles.kindSub}>% discount</div>
                  </div>
                </button>

                <button
                  type="button"
                  className={`${styles.kindCard} ${promoKind === 'FREE_SHIPPING' ? styles.kindActive : ''}`}
                  onClick={() => setPromoKind('FREE_SHIPPING')}
                >
                  <div className={styles.kindIcon}>🚚</div>
                  <div>
                    <div className={styles.kindTitle}>Free shipping</div>
                    <div className={styles.kindSub}>Shipping 100% off</div>
                  </div>
                </button>
              </div>

              <div className={styles.formGrid}>
                <div className={styles.split2}>
                  <div className={styles.field}>
                    <label className={styles.label}>Promo code</label>
                    <input
                      className={styles.input}
                      placeholder="e.g. SUMMERSALE20"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                    />
                    <div className={styles.hint}>Codes are stored uppercase with no spaces.</div>
                  </div>

                  <div className={styles.field}>
                    <label className={styles.label}>Promo name</label>
                    <input
                      className={styles.input}
                      placeholder="e.g. Summer sale"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>

                <div className={styles.split2}>
                  <div className={styles.field}>
                    <label className={styles.label}>
                      {promoKind === 'FREE_SHIPPING' ? 'Discount' : 'Discount'}
                    </label>

                    <div className={styles.pillInput} aria-disabled={promoKind === 'FREE_SHIPPING'}>
                      <span className={styles.pillIcon}>
                        {promoKind === 'PERCENT_OFF' ? '%' : '£'}
                      </span>
                      <input
                        className={styles.input}
                        inputMode="numeric"
                        disabled={promoKind === 'FREE_SHIPPING'}
                        placeholder={promoKind === 'PERCENT_OFF' ? 'e.g. 10' : 'e.g. 5'}
                        value={discountValue}
                        onChange={(e) => setDiscountValue(e.target.value)}
                      />
                    </div>
                    {promoKind === 'FREE_SHIPPING' && (
                      <div className={styles.hint}>
                        Free shipping promos don’t need an item discount.
                      </div>
                    )}
                  </div>

                  <div className={styles.field}>
                    <label className={styles.label}>Apply to</label>
                    <select
                      className={styles.select}
                      value={targetType}
                      onChange={(e) => setTargetType(e.target.value as TargetType)}
                    >
                      <option value="SITE_WIDE">All products</option>
                      <option value="CATEGORIES">Categories</option>
                      <option value="PRODUCTS">Products</option>
                    </select>

                    <div className={styles.hint}>
                      Category/product selection UI can be added next (search + multi-select).
                    </div>
                  </div>
                </div>

                {/* ✅ Shipping discount aligned */}
                <div className={styles.split2}>
                  <div className={styles.field}>
                    <label className={styles.label}>Shipping discount</label>

                    <label className={styles.checkRow}>
                      <input
                        type="checkbox"
                        checked={applyShipping}
                        onChange={(e) => setApplyShipping(e.target.checked)}
                        disabled={promoKind === 'FREE_SHIPPING'}
                      />
                      <span>
                        <strong>Add shipping discount</strong>
                        <div className={styles.hint}>
                          Works with Amount off and Percent off promos too.
                        </div>
                      </span>
                    </label>
                  </div>

                  <div className={styles.field}>
                    <label
                      className={styles.label}
                      style={{ opacity: applyShipping || promoKind === 'FREE_SHIPPING' ? 1 : 0.45 }}
                    >
                      0–100%. Use 100% for free shipping.
                    </label>

                    <div
                      className={styles.pillInput}
                      style={{ opacity: applyShipping || promoKind === 'FREE_SHIPPING' ? 1 : 0.45 }}
                    >
                      <span className={styles.pillIcon}>%</span>
                      <input
                        className={styles.input}
                        inputMode="numeric"
                        disabled={!(applyShipping || promoKind === 'FREE_SHIPPING')}
                        value={shippingPct}
                        onChange={(e) => setShippingPct(e.target.value)}
                        placeholder="e.g. 100"
                      />
                    </div>
                  </div>
                </div>

                <div className={styles.split2}>
                  <div className={styles.field}>
                    <label className={styles.label}>Valid between</label>
                    <input
                      className={styles.input}
                      type="date"
                      value={startsAt}
                      onChange={(e) => setStartsAt(e.target.value)}
                    />
                  </div>

                  <div className={styles.field}>
                    <label className={styles.label}>&nbsp;</label>
                    <input
                      className={styles.input}
                      type="date"
                      value={endsAt}
                      onChange={(e) => setEndsAt(e.target.value)}
                      disabled={noEnd}
                    />

                    <label className={styles.checkInline}>
                      <input
                        type="checkbox"
                        checked={noEnd}
                        onChange={(e) => setNoEnd(e.target.checked)}
                      />
                      <span>Don’t set an end date</span>
                    </label>
                  </div>
                </div>

                {/* ✅ Limits aligned */}
                <div className={styles.split2}>
                  <div className={styles.field}>
                    <label className={styles.label}>Limit uses</label>

                    <label className={styles.checkRow}>
                      <input
                        type="checkbox"
                        checked={limitTotal}
                        onChange={(e) => setLimitTotal(e.target.checked)}
                      />
                      <span>
                        <strong>Limit total number of uses</strong>
                        <div className={styles.hint}>Stops the promo after X redemptions.</div>
                      </span>
                    </label>

                    {limitTotal && (
                      <div className={styles.pillInput}>
                        <span className={styles.pillIcon}>#</span>
                        <input
                          className={styles.input}
                          inputMode="numeric"
                          placeholder="Total uses"
                          value={maxUsesTotal}
                          onChange={(e) => setMaxUsesTotal(e.target.value)}
                        />
                      </div>
                    )}
                  </div>

                  <div className={styles.field}>
                    <label className={styles.label}>&nbsp;</label>
                    <label className={styles.checkRow}>
                      <input
                        type="checkbox"
                        checked={limitPerCustomer}
                        onChange={(e) => setLimitPerCustomer(e.target.checked)}
                      />
                      <span>
                        <strong>Limit to one use per customer</strong>
                        <div className={styles.hint}>Sets max uses per user/email to 1.</div>
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              {err && <div className={styles.inlineError}>{err}</div>}
            </div>

            <div className={styles.modalFooter}>
              <button
                type="button"
                className={styles.secondaryBtn}
                onClick={closeModal}
                disabled={saving}
              >
                Cancel
              </button>
              <button
                type="button"
                className={styles.primaryBtn}
                onClick={createPromo}
                disabled={saving}
              >
                {saving ? 'Creating…' : 'Create promo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
