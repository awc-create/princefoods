import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';

type Role = 'HEAD' | 'STAFF' | 'VIEWER';
interface SessionUserWithRole {
  role?: Role | null;
}
const hasRole = (u: unknown): u is SessionUserWithRole =>
  !!u && typeof u === 'object' && 'role' in (u as Record<string, unknown>);

export const runtime = 'nodejs';

// ✅ add shipping_weight (grams)
const HEADERS = [
  'Pic',
  'Name',
  'SKU',
  'Price',
  'Inventory',
  'Collection',
  'shipping_weight'
] as const;
type CsvHeader = (typeof HEADERS)[number];

function esc(val: unknown): string {
  if (val == null) return '';
  const s = String(val);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function childCategory(full?: string | null) {
  if (!full) return '';
  const parts = full
    .split(';')
    .map((s) => s.trim())
    .filter(Boolean);
  return parts.length ? parts[parts.length - 1] : '';
}

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  const role: Role | undefined = hasRole(session?.user)
    ? (session!.user.role ?? undefined)
    : undefined;

  if (!role || (role !== 'HEAD' && role !== 'STAFF')) {
    return NextResponse.json({ message: 'Forbidden' }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);

  // A) explicit IDs export
  const idsParam = searchParams.get('ids');
  const ids = idsParam
    ? idsParam
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
    : null;

  // B) filtered export by search + collections (used when no ids are passed)
  const search = (searchParams.get('search') ?? '').trim();

  const collectionsParam = (searchParams.get('collections') ?? '').trim();
  const collections = collectionsParam
    ? collectionsParam
        .split(',')
        .map((s) => decodeURIComponent(s).trim())
        .filter(Boolean)
    : [];

  const where =
    ids && ids.length
      ? { id: { in: ids } }
      : {
          ...(search
            ? {
                OR: [
                  { name: { contains: search, mode: 'insensitive' as const } },
                  { sku: { contains: search, mode: 'insensitive' as const } },
                  { brand: { contains: search, mode: 'insensitive' as const } },
                  { collection: { contains: search, mode: 'insensitive' as const } }
                ]
              }
            : {}),
          ...(collections.length ? { collection: { in: collections } } : {})
        };

  const items = await prisma.product.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    select: {
      name: true,
      sku: true,
      price: true,
      inventory: true,
      collection: true,
      productImageUrl: true,
      shippingWeightGrams: true,
      weight: true // fallback if grams missing
    }
  });

  const lines: string[] = [];
  lines.push(HEADERS.join(','));

  for (const p of items) {
    const grams = p.shippingWeightGrams ?? (p.weight != null ? Math.round(p.weight * 1000) : '');

    const row: Record<CsvHeader, string | number> = {
      Pic: p.productImageUrl ?? '',
      Name: p.name ?? '',
      SKU: p.sku ?? '',
      Price: p.price != null ? String(p.price) : '',
      Inventory: p.inventory ?? '',
      Collection: childCategory(p.collection),
      shipping_weight: grams as number | ''
    };

    lines.push(HEADERS.map((h) => esc(row[h])).join(','));
  }

  const csv = lines.join('\n');

  return new NextResponse(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="products-list-export.csv"',
      'Cache-Control': 'no-store'
    }
  });
}
