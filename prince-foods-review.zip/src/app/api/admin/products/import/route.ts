import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

/* -------------------------------------------
   Types
------------------------------------------- */
type Role = 'HEAD' | 'STAFF' | 'VIEWER';
interface SessionUserWithRole {
  role?: Role | null;
}
const hasRole = (u: unknown): u is SessionUserWithRole =>
  !!u && typeof u === 'object' && 'role' in (u as Record<string, unknown>);

// One CSV row as parsed (original headers preserved)
type Row = Record<string, string>;
// Row after normalizing keys (lowercase + no spaces)
type NormalizedRow = Record<string, string>;

/* -------------------------------------------
   Image URL detection (unchanged)
------------------------------------------- */
const WIX_MEDIA_HOST = 'https://static.wixstatic.com';
const WIX_MEDIA_PREFIX = `${WIX_MEDIA_HOST}/media/`;
const WIX_ID_RE = /^[0-9a-f]{6,}_[^/]+~mv2\.[a-z0-9]+$/i;

type ImgDetect =
  | {
      url: string;
      source:
        | 'wix'
        | 'wix-id'
        | 'wix-media'
        | 'wix-image-v1'
        | 'google-drive'
        | 'google-photos'
        | 'google-static'
        | 'other';
    }
  | { url: null; source: 'invalid' };

function detectAndNormalizeImageUrl(input: unknown): ImgDetect {
  if (input == null) return { url: null, source: 'invalid' };
  let s = String(input).trim();
  if (!s) return { url: null, source: 'invalid' };
  if (s.startsWith('//')) s = 'https:' + s;
  if (WIX_ID_RE.test(s)) return { url: WIX_MEDIA_PREFIX + s, source: 'wix-id' };
  if (s.startsWith('/media/')) return { url: WIX_MEDIA_HOST + s, source: 'wix-media' };
  if (s.startsWith('wix:image://v1/')) {
    const last = s.split('/').pop();
    if (last && WIX_ID_RE.test(last))
      return { url: WIX_MEDIA_PREFIX + last, source: 'wix-image-v1' };
  }
  try {
    new URL(s);
  } catch {
    s = encodeURI(s);
  }
  if (!/^https?:\/\//i.test(s)) return { url: null, source: 'invalid' };
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    return { url: null, source: 'invalid' };
  }
  const host = u.hostname.toLowerCase();
  if (host === 'drive.google.com') {
    const parts = u.pathname.split('/').filter(Boolean);
    const fileIndex = parts.indexOf('file');
    let id: string | null = null;
    if (fileIndex !== -1) {
      const dIndex = parts.indexOf('d', fileIndex);
      if (dIndex !== -1 && parts[dIndex + 1]) id = parts[dIndex + 1];
    }
    id ??= u.searchParams.get('id');
    if (id) {
      const direct = new URL('https://drive.google.com/uc');
      direct.searchParams.set('export', 'view');
      direct.searchParams.set('id', id);
      return { url: direct.toString(), source: 'google-drive' };
    }
    return { url: null, source: 'invalid' };
  }
  if (host.endsWith('googleusercontent.com') || host.endsWith('ggpht.com'))
    return { url: u.toString(), source: 'google-photos' };
  if (host.endsWith('gstatic.com')) return { url: u.toString(), source: 'google-static' };
  if (host === 'static.wixstatic.com' || host.endsWith('.wixstatic.com'))
    return { url: u.toString(), source: 'wix' };
  return { url: u.toString(), source: 'other' };
}

/* -------------------------------------------
   CSV helpers (unchanged)
------------------------------------------- */
function splitCSVLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inQ) {
      if (c === '"') {
        if (line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQ = false;
        }
      } else cur += c;
    } else {
      if (c === ',') {
        out.push(cur);
        cur = '';
      } else if (c === '"') inQ = true;
      else cur += c;
    }
  }
  out.push(cur);
  return out;
}

interface ParsedCSV {
  headers: string[];
  rows: Row[];
}
function parseCSV(csv: string): ParsedCSV {
  const lines = csv.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (!lines.length) return { headers: [], rows: [] };
  const headers = splitCSVLine(lines[0]);
  const rows: Row[] = lines.slice(1).map((line) => {
    const cols = splitCSVLine(line);
    const obj: Row = {};
    headers.forEach((h, i) => {
      obj[h] = (cols[i] ?? '').trim();
    });
    return obj;
  });
  return { headers, rows };
}

function normalizeKeys(o: Row): NormalizedRow {
  const out: NormalizedRow = {};
  for (const k of Object.keys(o)) out[k.replace(/\s+/g, '').toLowerCase()] = o[k];
  return out;
}
function truthy(val: unknown): boolean | undefined {
  const v = String(val ?? '')
    .trim()
    .toUpperCase();
  if (v === 'TRUE') return true;
  if (v === 'FALSE') return false;
  return undefined;
}
function numOrNull(val: unknown): number | null {
  if (val === '' || val == null) return null;
  const n = Number(val);
  return Number.isFinite(n) ? n : null;
}
function pickKeys<T extends Record<string, unknown>>(obj: T, keys: string[]): Partial<T> {
  const out: Partial<T> = {};
  for (const k of keys)
    if (k in obj) (out as Record<string, unknown>)[k] = (obj as Record<string, unknown>)[k];
  return out;
}

function intOrNull(val: unknown): number | null {
  if (val == null || String(val).trim() === '') return null;
  const n = Math.trunc(Number(val));
  return Number.isFinite(n) && n > 0 ? n : null;
}

/* -------------------------------------------
   Weight parsing → grams
------------------------------------------- */
function parseWeightToGramsFromName(name: string): number | null {
  const s = name.toLowerCase();

  const multi = s.match(/(\d+)\s*[x×]\s*(\d+(?:\.\d+)?)\s*(kg|g|l|ml)\b/);
  if (multi) {
    const qty = Number(multi[1]);
    const unitVal = Number(multi[2]);
    const unit = multi[3];
    const per =
      unit === 'kg'
        ? unitVal * 1000
        : unit === 'g'
          ? unitVal
          : unit === 'l'
            ? unitVal * 1000
            : unit === 'ml'
              ? unitVal
              : 0;
    const grams = Math.round(qty * per);
    return grams > 0 ? grams : null;
  }

  const single = s.match(/(\d+(?:\.\d+)?)\s*(kg|g|l|ml)\b/);
  if (single) {
    const val = Number(single[1]);
    const unit = single[2];
    const grams =
      unit === 'kg'
        ? val * 1000
        : unit === 'g'
          ? val
          : unit === 'l'
            ? val * 1000
            : unit === 'ml'
              ? val
              : 0;
    return grams > 0 ? Math.round(grams) : null;
  }

  return null;
}

// Normalize a CSV "weight" field (string) → kilograms
function normalizeWeightKg(raw?: string | null): number | null {
  if (!raw) return null;
  const s = raw.trim().toLowerCase();
  const m = s.match(/(\d+(?:\.\d+)?)\s*(kg|g|l|ml)\b/);
  if (!m) {
    const n = Number(s);
    return Number.isFinite(n) ? n : null; // assume already kg if bare number
  }
  const val = Number(m[1]);
  const unit = m[2];
  if (unit === 'kg') return val;
  if (unit === 'g') return val / 1000;
  if (unit === 'l') return val; // treat 1L ≈ 1kg
  if (unit === 'ml') return val / 1000;
  return null;
}

/* -------------------------------------------
   Map CSV row → Prisma Product data
------------------------------------------- */
function deriveWeights(row: NormalizedRow): { weightKg: number | null; grams: number | null } {
  const explicitKg = normalizeWeightKg(row.weight ?? null);
  if (explicitKg != null) {
    return { weightKg: explicitKg, grams: Math.round(explicitKg * 1000) };
  }

  const swRaw = row.shipping_weight ?? row.shippingweight ?? null;
  if (swRaw != null && swRaw !== '') {
    const g = Math.round(Number(swRaw));
    if (Number.isFinite(g) && g > 0) return { weightKg: g / 1000, grams: g };
  }

  const name = (row.name ?? '').trim();
  if (name) {
    const g = parseWeightToGramsFromName(name);
    if (g != null) return { weightKg: g / 1000, grams: g };
  }

  return { weightKg: null, grams: null };
}

function mapToProductCreate(id: string, r: NormalizedRow) {
  const primary = r.productimageurl?.trim();
  const secondary = r.image?.trim();
  const chosen = primary && primary.length > 0 ? primary : (secondary ?? null);
  const detected = detectAndNormalizeImageUrl(chosen && chosen.length > 0 ? chosen : null);

  const { weightKg, grams } = deriveWeights(r);

  // ✅ support several possible column names
  const caseQty =
    intOrNull(
      r.caseqty ??
        r.unitspercase ??
        r.unitsperbox ??
        r.masterboxqty ??
        r.unitsincase ??
        r.unitspermasterbox
    ) ?? null;

  return {
    id,
    fieldType: r.fieldtype || 'Product',
    name: r.name || '',
    description: r.description || null,

    productImageUrl: detected.url,

    collection: r.collection || null,
    sku: r.sku || null,
    ribbon: r.ribbon || null,
    price: numOrNull(r.price),
    surcharge: numOrNull(r.surcharge),
    visible: truthy(r.visible) ?? true,
    discountMode: r.discountmode || null,
    discountValue: numOrNull(r.discountvalue),
    inventory: r.inventory || null,

    // ✅ wholesale
    caseQty,

    // ✅ weights
    weight: weightKg, // kg
    shippingWeightGrams: grams ?? null, // grams

    cost: numOrNull(r.cost),

    productOptionName1: r.productoptionname1 || null,
    productOptionType1: r.productoptiontype1 || null,
    productOptionDescription1: r.productoptiondescription1 || null,
    productOptionName2: r.productoptionname2 || null,
    productOptionType2: r.productoptiontype2 || null,
    productOptionDescription2: r.productoptiondescription2 || null,
    productOptionName3: r.productoptionname3 || null,
    productOptionType3: r.productoptiontype3 || null,
    productOptionDescription3: r.productoptiondescription3 || null,
    productOptionName4: r.productoptionname4 || null,
    productOptionType4: r.productoptiontype4 || null,
    productOptionDescription4: r.productoptiondescription4 || null,
    productOptionName5: r.productoptionname5 || null,
    productOptionType5: r.productoptiontype5 || null,
    productOptionDescription5: r.productoptiondescription5 || null,
    productOptionName6: r.productoptionname6 || null,
    productOptionType6: r.productoptiontype6 || null,
    productOptionDescription6: r.productoptiondescription6 || null,

    additionalInfoTitle1: r.additionalinfotitle1 || null,
    additionalInfoDescription1: r.additionalinfodescription1 || null,
    additionalInfoTitle2: r.additionalinfotitle2 || null,
    additionalInfoDescription2: r.additionalinfodescription2 || null,
    additionalInfoTitle3: r.additionalinfotitle3 || null,
    additionalInfoDescription3: r.additionalinfodescription3 || null,
    additionalInfoTitle4: r.additionalinfotitle4 || null,
    additionalInfoDescription4: r.additionalinfodescription4 || null,
    additionalInfoTitle5: r.additionalinfotitle5 || null,
    additionalInfoDescription5: r.additionalinfodescription5 || null,
    additionalInfoTitle6: r.additionalinfotitle6 || null,
    additionalInfoDescription6: r.additionalinfodescription6 || null,

    customTextField1: r.customtextfield1 || null,
    customTextCharLimit1: r.customtextcharlimit1 ? Number(r.customtextcharlimit1) : null,
    customTextMandatory1: truthy(r.customtextmandatory1) ?? null,
    customTextField2: r.customtextfield2 || null,
    customTextCharLimit2: r.customtextcharlimit2 ? Number(r.customtextcharlimit2) : null,
    customTextMandatory2: truthy(r.customtextmandatory2) ?? null,

    brand: r.brand || null
  };
}

function mapToProductUpdate(r: NormalizedRow) {
  const d = mapToProductCreate('ignore', r);
  // @ts-expect-error remove id for update shape
  delete d.id;
  return d;
}

/* -------------------------------------------
   POST /api/admin/products/import
------------------------------------------- */
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const role: Role | undefined = hasRole(session?.user)
    ? (session!.user.role ?? undefined)
    : undefined;
  if (!role || (role !== 'HEAD' && role !== 'STAFF')) {
    return NextResponse.json({ message: 'Forbidden' }, { status: 403 });
  }

  const form = await req.formData().catch(() => null);
  if (!form) return NextResponse.json({ message: 'Invalid form data' }, { status: 400 });

  const file = form.get('file');
  if (!(file instanceof File))
    return NextResponse.json({ message: 'Missing file' }, { status: 400 });

  const text = await file.text();
  const { headers, rows } = parseCSV(text);
  if (rows.length === 0) return NextResponse.json({ message: 'Empty file' }, { status: 400 });

  const hasFieldType = headers.map((h) => h.toLowerCase()).includes('fieldtype');

  let upserted = 0,
    skipped = 0;

  if (hasFieldType) {
    // Wix-style: pair Product + Variant by handleId
    interface AccValue {
      product?: NormalizedRow;
      variant?: NormalizedRow;
    }
    const acc: Record<string, AccValue> = {};

    for (const r of rows) {
      const row = normalizeKeys(r);
      const handleId = (row.handleid ?? '').trim();
      const fieldType = (row.fieldtype ?? '').trim();
      if (!handleId) {
        skipped++;
        continue;
      }
      acc[handleId] ??= {};
      if (fieldType === 'Product') acc[handleId].product = row;
      else if (fieldType === 'Variant') acc[handleId].variant = row;
      else acc[handleId].product = { ...(acc[handleId].product ?? {}), ...row };
    }

    for (const id of Object.keys(acc)) {
      const p = acc[id].product ?? {};
      const v = acc[id].variant ?? {};
      const merged: NormalizedRow = {
        ...p,
        ...(pickKeys(v, [
          'sku',
          'price',
          'inventory',
          'weight',
          'shipping_weight',
          'productimageurl',
          'image',
          // ✅ allow case qty to be pulled from Variant row too if present
          'caseqty',
          'unitspercase',
          'unitsperbox'
        ]) as NormalizedRow)
      };

      try {
        await prisma.product.upsert({
          where: { id },
          update: mapToProductUpdate(merged),
          create: mapToProductCreate(id, merged)
        });
        upserted++;
      } catch {
        skipped++;
      }
    }
  } else {
    // Simple CSV (no fieldType)
    for (const r of rows) {
      const row = normalizeKeys(r);
      const id = (row.id ?? row.handleid ?? '').trim();
      const name = (row.name ?? '').trim();
      if (!id || !name) {
        skipped++;
        continue;
      }

      try {
        await prisma.product.upsert({
          where: { id },
          update: mapToProductUpdate(row),
          create: mapToProductCreate(id, row)
        });
        upserted++;
      } catch {
        skipped++;
      }
    }
  }

  return NextResponse.json({ ok: true, upserted, skipped });
}
