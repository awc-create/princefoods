'use client';

import { useCart } from '@/lib/cart-store';
import { signOut } from 'next-auth/react';
import Link from 'next/link';
import { useEffect, useMemo, useState, useTransition } from 'react';
import styles from './TabsAccount.module.scss';

import AddressesTab from '@/components/account/tabs/addresses/AddressesTab';
import OrdersTab from '@/components/account/tabs/orders/OrdersTab';

type Tab = 'overview' | 'profile' | 'orders' | 'addresses' | 'wallet' | 'security';

const ALL_TABS: Tab[] = ['overview', 'profile', 'orders', 'addresses', 'wallet', 'security'];

interface UserDTO {
  id: string;
  email: string;
  name: string | null;
  firstName: string | null;
  lastName: string | null;
  phoneE164: string | null;
  emailVerified: string | null;
  createdAt: string | Date;
}

export default function AccountClient({
  user,
  initialTab = 'overview'
}: {
  user: UserDTO;
  initialTab?: Tab;
}) {
  const cart = useCart();
  const cartCount = useMemo(() => {
    const items = (cart as unknown as { items?: unknown[] })?.items;
    return Array.isArray(items) ? items.length : 0;
  }, [cart]);

  const [tab, setTab] = useState<Tab>(initialTab);
  const [saving, startSaving] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const [profile, setProfile] = useState({
    firstName: user.firstName ?? '',
    lastName: user.lastName ?? '',
    name: user.name ?? '',
    phoneE164: user.phoneE164 ?? ''
  });

  const verified = !!user.emailVerified;

  function gotoTab(next: Tab) {
    setTab(next);

    const params = new URLSearchParams(window.location.search);
    params.set('tab', next);

    const qs = params.toString();
    const path = `${window.location.pathname}${qs ? `?${qs}` : ''}`;

    window.history.pushState({}, '', path);
  }

  // ✅ Read tab from URL on mount + handle back/forward
  useEffect(() => {
    const read = () => {
      const sp = new URLSearchParams(window.location.search);
      const t = sp.get('tab') as Tab | null;
      if (t && ALL_TABS.includes(t)) setTab(t);
    };

    read();
    window.addEventListener('popstate', read);
    return () => window.removeEventListener('popstate', read);
  }, []);

  function onChange<K extends keyof typeof profile>(key: K, v: string) {
    setProfile((p) => ({ ...p, [key]: v }));
  }

  function saveProfile() {
    setMsg(null);
    setErr(null);
    startSaving(async () => {
      try {
        const res = await fetch('/api/account/profile', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(profile)
        });
        const data = (await res.json()) as { ok?: boolean; error?: string };
        if (data.ok) setMsg('Profile updated');
        else setErr(data.error ?? 'Could not update profile');
      } catch {
        setErr('Could not update profile');
      }
    });
  }

  async function resendVerify() {
    setMsg(null);
    setErr(null);
    try {
      const res = await fetch('/api/auth/send-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user.email, resend: true, next: '/account?tab=security' })
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (data.ok) setMsg('If your email started verification, a new code/link is on the way.');
      else setErr(data.error ?? 'Could not send verification');
    } catch {
      setErr('Could not send verification');
    }
  }

  return (
    <>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.identity}>
          <div className={styles.avatarWrap}>
            <div className={styles.avatar}>
              {(user.name ?? user.email).slice(0, 1).toUpperCase()}
            </div>
          </div>
          <div>
            <h1 className={styles.title}>{user.name ?? user.email}</h1>
            <p className={styles.sub}>
              Member since {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        <button
          className={`${styles.btn} ${styles.btnGhost}`}
          onClick={() => signOut({ callbackUrl: '/' })}
          type="button"
        >
          Sign out
        </button>
      </header>

      {/* Tabs */}
      <nav className={styles.tabs} role="tablist" aria-label="Account sections">
        {ALL_TABS.map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            className={`${styles.tab} ${tab === t ? styles.active : ''}`}
            onClick={() => gotoTab(t)}
            type="button"
          >
            {t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </nav>

      {/* Panels */}
      <section className={styles.panel}>
        {/* ✅ OVERVIEW */}
        {tab === 'overview' && (
          <div className={styles.cards}>
            {!verified && (
              <div className={`${styles.card} ${styles.fullRow}`}>
                <h3 className={styles.cardTitle}>Verify your email</h3>
                <p className={styles.muted}>Verify to secure your account and enable checkout.</p>
                <div className={styles.rowBtns}>
                  <Link
                    className={`${styles.btn} ${styles.btnLine}`}
                    href={`/verify?email=${encodeURIComponent(
                      user.email
                    )}&next=/account?tab=overview`}
                  >
                    Enter code
                  </Link>
                  <button
                    className={`${styles.btn} ${styles.btnPrimaryAlt}`}
                    onClick={resendVerify}
                    type="button"
                  >
                    Send new code
                  </button>
                </div>
              </div>
            )}

            {/* Card buttons that switch tabs */}
            <button type="button" className={styles.cardBtn} onClick={() => gotoTab('orders')}>
              <div className={`${styles.card} ${styles.cardBtnInner}`}>
                <div className={styles.cardTop}>
                  <h3 className={styles.cardTitle}>Orders</h3>
                  <span className={styles.chev}>→</span>
                </div>
                <p className={styles.muted}>View your past orders and receipts.</p>
                <div className={styles.rowBtns}>
                  <span className={`${styles.btn} ${styles.btnGhost} ${styles.btnSm}`}>
                    View orders
                  </span>
                </div>
              </div>
            </button>

            <button type="button" className={styles.cardBtn} onClick={() => gotoTab('addresses')}>
              <div className={`${styles.card} ${styles.cardBtnInner}`}>
                <div className={styles.cardTop}>
                  <h3 className={styles.cardTitle}>Addresses</h3>
                  <span className={styles.chev}>→</span>
                </div>
                <p className={styles.muted}>Manage shipping and billing addresses.</p>
                <div className={styles.rowBtns}>
                  <span className={`${styles.btn} ${styles.btnGhost} ${styles.btnSm}`}>Manage</span>
                </div>
              </div>
            </button>

            <button type="button" className={styles.cardBtn} onClick={() => gotoTab('security')}>
              <div className={`${styles.card} ${styles.cardBtnInner}`}>
                <div className={styles.cardTop}>
                  <h3 className={styles.cardTitle}>Security</h3>
                  <span className={styles.chev}>→</span>
                </div>
                <p className={styles.muted}>Email verification and password.</p>
                <div className={styles.rowBtns}>
                  <span className={`${styles.btn} ${styles.btnGhost} ${styles.btnSm}`}>Open</span>
                </div>
              </div>
            </button>

            {/* Quick actions */}
            <div className={`${styles.card} ${styles.fullRow}`}>
              <h3 className={styles.cardTitle}>Quick actions</h3>
              <p className={styles.muted}>Jump back into shopping or checkout.</p>

              <div className={styles.rowBtns}>
                {cartCount > 0 ? (
                  <Link className={`${styles.btn} ${styles.btnPrimary}`} href="/checkout">
                    Continue checkout ({cartCount})
                  </Link>
                ) : (
                  <button
                    type="button"
                    className={`${styles.btn} ${styles.btnPrimary} ${styles.btnDisabled}`}
                    disabled
                    aria-disabled="true"
                    title="Add items to your cart to checkout"
                  >
                    Continue checkout
                  </button>
                )}

                <Link className={`${styles.btn} ${styles.btnGhost}`} href="/cart">
                  View cart
                </Link>

                <Link className={`${styles.btn} ${styles.btnGhost}`} href="/shop">
                  Browse shop
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* PROFILE */}
        {tab === 'profile' && (
          <>
            <h2 className={styles.h2}>Profile</h2>

            <div className={styles.formRow}>
              <label>First name</label>
              <input
                value={profile.firstName}
                onChange={(e) => onChange('firstName', e.target.value)}
              />
            </div>

            <div className={styles.formRow}>
              <label>Last name</label>
              <input
                value={profile.lastName}
                onChange={(e) => onChange('lastName', e.target.value)}
              />
            </div>

            <div className={styles.formRow}>
              <label>Display name</label>
              <input value={profile.name} onChange={(e) => onChange('name', e.target.value)} />
            </div>

            <div className={styles.formRow}>
              <label>Phone</label>
              <input
                placeholder="+44…"
                value={profile.phoneE164}
                onChange={(e) => onChange('phoneE164', e.target.value)}
              />
            </div>

            {err && <p className={styles.error}>{err}</p>}
            {msg && <p className={styles.ok}>{msg}</p>}

            <div className={styles.actionsRow}>
              <button
                disabled={saving}
                onClick={saveProfile}
                className={`${styles.btn} ${styles.btnPrimary}`}
                type="button"
              >
                {saving ? 'Saving…' : 'Save changes'}
              </button>

              <button
                onClick={() =>
                  setProfile({
                    firstName: user.firstName ?? '',
                    lastName: user.lastName ?? '',
                    name: user.name ?? '',
                    phoneE164: user.phoneE164 ?? ''
                  })
                }
                className={`${styles.btn} ${styles.btnGhost}`}
                type="button"
              >
                Discard
              </button>
            </div>
          </>
        )}

        {/* ORDERS */}
        {tab === 'orders' && <OrdersTab />}

        {/* ADDRESSES */}
        {tab === 'addresses' && <AddressesTab />}

        {tab === 'wallet' && <p className={styles.muted}>Wallet settings here…</p>}

        {/* SECURITY */}
        {tab === 'security' && (
          <>
            <h2 className={styles.h2}>Security</h2>

            <div className={styles.kv}>
              <span>Email</span>
              <span>
                {user.email} {verified ? '✅' : '(unverified)'}
              </span>
            </div>

            {!verified && (
              <div className={styles.rowBtns}>
                <Link
                  className={`${styles.btn} ${styles.btnLine}`}
                  href={`/verify?email=${encodeURIComponent(user.email)}&next=/account?tab=security`}
                >
                  Enter code
                </Link>
                <button
                  className={`${styles.btn} ${styles.btnPrimaryAlt}`}
                  onClick={resendVerify}
                  type="button"
                >
                  Resend verification
                </button>
              </div>
            )}

            <div className={styles.rowBtns}>
              <Link className={`${styles.btn} ${styles.btnGhost}`} href="/reset-password">
                Change password
              </Link>
            </div>
          </>
        )}
      </section>
    </>
  );
}
