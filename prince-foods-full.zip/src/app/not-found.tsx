// src/app/not-found.tsx
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function NotFound() {
  return (
    <main style={{ padding: '3rem 1.5rem', textAlign: 'center' }}>
      <h1>404 — Page not found</h1>
      <p>Sorry, we couldn’t find that page.</p>
    </main>
  );
}
