// src/app/admin/login/page.tsx
import { Suspense } from 'react';
import AdminLoginClient from './AdminLoginClient';

export const dynamic = 'force-dynamic';

export default function AdminLoginPage() {
  return (
    <Suspense fallback={null}>
      <AdminLoginClient />
    </Suspense>
  );
}
