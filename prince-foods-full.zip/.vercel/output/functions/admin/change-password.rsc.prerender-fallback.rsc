1:I[6975,[],"HTTPAccessFallbackBoundary"]
2:I[7201,["6711","static/chunks/8e1d74a4-f18ded39f8db71a8.js","6874","static/chunks/6874-d76bc1924bcd710f.js","3063","static/chunks/3063-aebeb7795bfdd852.js","6454","static/chunks/6454-fbfdc4ef35dd001f.js","4298","static/chunks/4298-9ea569c4fb56c087.js","4346","static/chunks/4346-62dfafe5b832c320.js","7177","static/chunks/app/layout-fe18c2cd7c0f4f4e.js"],"default"]
3:I[7555,[],""]
4:I[1295,[],""]
5:"$Sreact.fragment"
6:I[4970,[],"ClientSegmentRoot"]
7:I[1243,["6874","static/chunks/6874-d76bc1924bcd710f.js","6454","static/chunks/6454-fbfdc4ef35dd001f.js","7581","static/chunks/app/admin/layout-2a990a237664c5cb.js"],"default"]
9:I[894,[],"ClientPageRoot"]
a:I[3705,["6267","static/chunks/app/admin/change-password/page-61e72467a69f7b5c.js"],"default"]
d:I[9665,[],"MetadataBoundary"]
f:I[9665,[],"OutletBoundary"]
12:I[4911,[],"AsyncMetadataOutlet"]
16:I[9665,[],"ViewportBoundary"]
18:I[6614,[],""]
:HL["/_next/static/css/4a321c7cd3079001.css","style"]
:HL["/_next/static/css/5f151aaee6e484a0.css","style"]
0:{"P":null,"b":"UxAfRAaLjt0NBaKsYK2TJ","p":"","c":["","admin","change-password",""],"i":false,"f":[[["",{"children":["admin",{"children":["change-password",{"children":["__PAGE__",{}]}]}],"modal":["__DEFAULT__",{}]},"$undefined","$undefined",true],["",["$","$L1","c",{"notFound":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/4a321c7cd3079001.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":["$","$L2",null,{"modal":"$undefined","children":[[],["$","main",null,{"style":{"padding":"3rem 1.5rem","textAlign":"center"},"children":[["$","h1",null,{"children":"404 — Page not found"}],["$","p",null,{"children":"Sorry, we couldn’t find that page."}]]}]]}]}]}]],"children":["$0:f:0:1:1:props:notFound:0",["$","html",null,{"lang":"en","children":["$","body",null,{"children":["$","$L2",null,{"modal":["$","$L3",null,{"parallelRouterKey":"modal","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}],"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","main",null,{"style":{"padding":"3rem 1.5rem","textAlign":"center"},"children":[["$","h1",null,{"children":"404 — Page not found"}],["$","p",null,{"children":"Sorry, we couldn’t find that page."}]]}],"$0:f:0:1:1:props:notFound:1:props:children:props:children:props:children:0"],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}],{"children":["admin",["$","$5","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/5f151aaee6e484a0.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","$L6",null,{"Component":"$7","slots":{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]},"params":{},"promise":"$@8"}]]}],{"children":["change-password",["$","$5","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$5","c",{"children":[["$","$L9",null,{"Component":"$a","searchParams":{},"params":"$0:f:0:1:2:children:1:props:children:1:props:params","promises":["$@b","$@c"]}],["$","$Ld",null,{"children":"$Le"}],null,["$","$Lf",null,{"children":["$L10","$L11",["$","$L12",null,{"promise":"$@13"}]]}]]}],{},null,false]},null,false]},null,false],"modal":["__DEFAULT__",["$","$5","c",{"children":[null,"$undefined",null,["$","$Lf",null,{"children":["$L14","$L15","$undefined"]}]]}],{},null,false]},null,false],["$","$5","h",{"children":[null,["$","$5","1hiSNc_gGDh5khdftk531",{"children":[["$","$L16",null,{"children":"$L17"}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],null]}],false]],"m":"$undefined","G":["$18","$undefined"],"s":false,"S":true}
19:"$Sreact.suspense"
1a:I[4911,[],"AsyncMetadata"]
8:{}
b:{}
c:{}
e:["$","$19",null,{"fallback":null,"children":["$","$L1a",null,{"promise":"$@1b"}]}]
11:null
14:null
15:null
17:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
10:null
1b:{"metadata":[["$","title","0",{"children":"Prince Foods"}],["$","meta","1",{"name":"description","content":"South Asian groceries at unbeatable everyday prices."}],["$","link","2",{"rel":"canonical","href":"http://localhost:3000/"}],["$","meta","3",{"property":"og:title","content":"Prince Foods"}],["$","meta","4",{"property":"og:description","content":"South Asian groceries at unbeatable everyday prices."}],["$","meta","5",{"property":"og:image","content":"http://localhost:3000/og.png"}],["$","meta","6",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","7",{"name":"twitter:title","content":"Prince Foods"}],["$","meta","8",{"name":"twitter:description","content":"South Asian groceries at unbeatable everyday prices."}],["$","meta","9",{"name":"twitter:image","content":"http://localhost:3000/og.png"}],["$","link","10",{"rel":"icon","href":"http://localhost:3000/favicon.ico"}]],"error":null,"digest":"$undefined"}
13:{"metadata":"$1b:metadata","error":null,"digest":"$undefined"}
