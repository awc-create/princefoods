// src/lib/offers-engine.ts
import type {
  OfferAdminForm,
  OfferAppliedMeta,
  OfferBOGOF,
  OfferLineDiscount,
  OfferLineParticipant,
  OfferPayload,
  OfferSpendXGetY,
  OfferTargetRule,
  OfferXForFixedPrice,
  OfferXForY
} from '@/types/offers';

export type Money = number; // pence

export interface CartLine {
  productId?: string | null;
  sku?: string | null;
  name: string;
  unitPricePence: Money;
  qty: number;

  categoryId?: string | null;
  tags?: string[] | null;
  collection?: string | null;
}

export interface OfferEvalInput {
  now?: Date;
  lines: CartLine[];
  code?: string | null;
}

export interface OfferApplied {
  offerId: string;
  name: string;
  kind: OfferPayload['kind'];

  mode: OfferAdminForm['mode'];
  codeUsed: string | null;

  discountPence: Money;

  meta?: OfferAppliedMeta;
}

export interface OfferEngineResult {
  subtotalPence: Money;

  // ✅ offers actually used (affects totals)
  applied: OfferApplied[];
  discountTotalPence: Money;

  // ✅ offers that WOULD apply (for preview UI)
  eligible: OfferApplied[];

  autoAdd: Array<{
    reasonOfferId: string;
    productId?: string | null;
    sku?: string | null;
    name: string;
    qty: number;
  }>;
}

/* ---------------- key helpers ---------------- */

const normName = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');

function lineKey(x: { productId?: string | null; sku?: string | null; name: string }) {
  if (x.productId) return `pid:${x.productId}`;
  if (x.sku) return `sku:${x.sku}`;
  return `name:${normName(x.name)}`;
}

export function evaluateOffers(
  allOffers: OfferAdminForm[],
  input: OfferEvalInput
): OfferEngineResult {
  const now = input.now ?? new Date();
  const subtotal = sumSubtotal(input.lines);

  const eligibleRaw = allOffers
    .filter((o) => isOfferActive(o, now))
    .filter((o) => isModeEligible(o, input.code))
    .map((o) => ({ offer: o, eval: evalOffer(o, input.lines, subtotal) }))
    .filter((x) => x.eval.discountPence > 0 || x.eval.autoAdd.length > 0);

  // ✅ Build "eligible" preview list (all offers that would apply)
  const eligible: OfferApplied[] = eligibleRaw.map((x) => {
    const o = x.offer;
    const codeUsed = resolveCodeUsed(o, input.code);

    let disc = x.eval.discountPence;

    // cap for preview as well (keeps display sane)
    if (typeof o.maxDiscountPerOrderPence === 'number') {
      disc = Math.min(disc, o.maxDiscountPerOrderPence);
    }

    return {
      offerId: o.id!,
      name: o.name,
      kind: o.payload.kind,
      mode: o.mode,
      codeUsed,
      discountPence: Math.max(0, Math.trunc(disc)),
      meta: x.eval.meta
    };
  });

  const stackAllowed = eligibleRaw
    .filter((x) => x.offer.stackingMode === 'STACK_ALLOWED')
    .sort((a, b) => b.offer.priority - a.offer.priority);

  const nonStack = eligibleRaw
    .filter((x) => x.offer.stackingMode !== 'STACK_ALLOWED')
    .sort((a, b) => b.offer.priority - a.offer.priority);

  let winner: (typeof nonStack)[number] | null = null;

  if (nonStack.length) {
    const hasPriorityWins = nonStack.some((x) => x.offer.stackingMode === 'HIGHEST_PRIORITY_WINS');
    winner = hasPriorityWins
      ? nonStack[0]
      : nonStack.reduce((best, cur) =>
          cur.eval.discountPence > best.eval.discountPence ? cur : best
        );
  }

  const chosen = [...stackAllowed, ...(winner ? [winner] : [])];

  const applied: OfferApplied[] = [];
  const autoAdd: OfferEngineResult['autoAdd'] = [];

  let discountTotal = 0;

  for (const c of chosen) {
    const o = c.offer;
    const codeUsed = resolveCodeUsed(o, input.code);

    let disc = c.eval.discountPence;

    if (typeof o.maxDiscountPerOrderPence === 'number') {
      disc = Math.min(disc, o.maxDiscountPerOrderPence);
    }

    if (o.preventFreeOrder) {
      const maxAllowed = Math.max(0, subtotal - 1); // leave 1p
      disc = Math.min(disc, maxAllowed - discountTotal);
      disc = Math.max(0, disc);
    }

    if (disc > 0) {
      discountTotal += disc;
      applied.push({
        offerId: o.id!,
        name: o.name,
        kind: o.payload.kind,
        mode: o.mode,
        codeUsed,
        discountPence: Math.max(0, Math.trunc(disc)),
        meta: c.eval.meta
      });
    }

    for (const a of c.eval.autoAdd) autoAdd.push(a);
  }

  return {
    subtotalPence: subtotal,
    applied,
    discountTotalPence: discountTotal,
    eligible,
    autoAdd
  };
}

/* ---------------- helpers ---------------- */

function sumSubtotal(lines: CartLine[]): Money {
  return lines.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);
}

function isOfferActive(o: OfferAdminForm, now: Date) {
  if (o.status !== 'ACTIVE') return false;
  if (o.startsAt) {
    const d = new Date(o.startsAt);
    if (!Number.isNaN(d.getTime()) && now < d) return false;
  }
  if (o.endsAt) {
    const d = new Date(o.endsAt);
    if (!Number.isNaN(d.getTime()) && now > d) return false;
  }
  return true;
}

function isModeEligible(o: OfferAdminForm, typedCode?: string | null) {
  if (o.mode === 'AUTO') return true;
  if (o.mode === 'CODE') return Boolean(typedCode && o.code && norm(typedCode) === norm(o.code));
  if (!typedCode) return true;
  if (!o.code) return true;
  return norm(typedCode) === norm(o.code);
}

function resolveCodeUsed(o: OfferAdminForm, typedCode?: string | null) {
  if (!typedCode) return null;
  if (!o.code) return null;
  return norm(typedCode) === norm(o.code) ? norm(typedCode) : null;
}

function norm(s: string) {
  return s.trim().toUpperCase().replace(/\s+/g, '');
}

interface Eval {
  discountPence: Money;
  autoAdd: OfferEngineResult['autoAdd'];
  meta?: OfferAppliedMeta;
}

function evalOffer(o: OfferAdminForm, lines: CartLine[], subtotal: Money): Eval {
  const p = o.payload;

  switch (p.kind) {
    case 'PERCENT_OFF': {
      const pool = p.data.pool ?? [{ type: 'ALL_PRODUCTS' } satisfies OfferTargetRule];
      const matched = matchLines(lines, pool);
      const base = matched.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);

      const pct = clampInt((p.data as { percent: number }).percent, 0, 100);
      const discount = Math.floor((base * pct) / 100);

      const participants = toLineParticipants(explodeUnits(matched), 'ELIGIBLE');

      return {
        discountPence: discount,
        autoAdd: [],
        meta: {
          basePence: base,
          pct,
          lineParticipants: participants,
          lineDiscounts: []
        }
      };
    }

    case 'AMOUNT_OFF': {
      const pool = p.data.pool ?? [{ type: 'ALL_PRODUCTS' } satisfies OfferTargetRule];
      const matched = matchLines(lines, pool);
      const base = matched.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);

      const amt = Math.max(0, (p.data as { amountPence: number }).amountPence);
      const discount = Math.min(amt, base);

      const participants = toLineParticipants(explodeUnits(matched), 'ELIGIBLE');

      return {
        discountPence: discount,
        autoAdd: [],
        meta: {
          basePence: base,
          lineParticipants: participants,
          lineDiscounts: []
        }
      };
    }

    case 'X_FOR_Y': {
      const data = p.data as OfferXForY;
      const matched = matchLines(lines, data.pool);
      const units = explodeUnits(matched);

      if (units.length < data.buyQty) return { discountPence: 0, autoAdd: [] };

      const groups = Math.floor(units.length / data.buyQty);
      const freeCountPerGroup = Math.max(0, data.buyQty - data.payQty);
      const freeCount = groups * freeCountPerGroup;

      const usedCount = groups * data.buyQty;
      const participantsUnits = units.slice(0, usedCount);

      const cheapestFirst = [...units].sort((a, b) => a.unitPricePence - b.unitPricePence);
      const freeUnits = cheapestFirst.slice(0, freeCount);

      const discount = freeUnits.reduce((sum, u) => sum + u.unitPricePence, 0);
      const lineDiscounts = toLineDiscounts(freeUnits, 'FREE');
      const lineParticipants = toLineParticipants(participantsUnits, 'ELIGIBLE');

      return {
        discountPence: discount,
        autoAdd: [],
        meta: { groups, freeCount, lineDiscounts, lineParticipants }
      };
    }

    case 'X_FOR_FIXED_PRICE': {
      const data = p.data as OfferXForFixedPrice;
      const matched = matchLines(lines, data.pool);
      const units = explodeUnits(matched);

      if (units.length < data.qty) return { discountPence: 0, autoAdd: [] };

      const groups = Math.floor(units.length / data.qty);
      if (groups <= 0) return { discountPence: 0, autoAdd: [] };

      const sortedDesc = [...units].sort((a, b) => b.unitPricePence - a.unitPricePence);

      let discount = 0;
      let idx = 0;

      const discountedUnits: Array<CartLine & { _unit?: true }> = [];
      const participantUnits: Array<CartLine & { _unit?: true }> = [];

      for (let g = 0; g < groups; g++) {
        const groupUnits = sortedDesc.slice(idx, idx + data.qty);
        idx += data.qty;

        participantUnits.push(...groupUnits);

        const groupSum = groupUnits.reduce((sum, u) => sum + u.unitPricePence, 0);
        const fixed = Math.max(0, data.pricePence);

        if (groupSum > fixed) {
          discount += groupSum - fixed;
          discountedUnits.push(...groupUnits);
        }
      }

      const lineDiscounts = toLineDiscounts(discountedUnits, 'DISCOUNT');
      const lineParticipants = toLineParticipants(participantUnits, 'ELIGIBLE');

      return {
        discountPence: discount,
        autoAdd: [],
        meta: { groups, lineDiscounts, lineParticipants }
      };
    }

    case 'BOGOF': {
      const data = p.data as OfferBOGOF;

      const samePool = samePoolRules(data.buyPool, data.getPool);

      const buyUnits = explodeUnits(matchLines(lines, data.buyPool));
      const getUnits = explodeUnits(matchLines(lines, data.getPool));

      const groupSize = Math.max(1, data.buyQty);
      const freePerGroup = Math.max(0, data.getQty);

      if (buyUnits.length < groupSize) return { discountPence: 0, autoAdd: [] };

      const groups = Math.floor(buyUnits.length / groupSize);
      const freeCount = groups * freePerGroup;
      if (freeCount <= 0) return { discountPence: 0, autoAdd: [] };

      const autoAdd: OfferEngineResult['autoAdd'] = [];

      const usedBuyCount = groups * groupSize;
      const usedBuyUnits = buyUnits.slice(0, usedBuyCount);

      const discountSource = samePool ? buyUnits : getUnits;

      if (!samePool && discountSource.length <= 0) {
        if (data.autoAddGetItem) {
          const short = freeCount;
          const candidate = [...buyUnits].sort((a, b) => a.unitPricePence - b.unitPricePence)[0];
          if (candidate) {
            autoAdd.push({
              reasonOfferId: o.id!,
              productId: candidate.productId ?? null,
              sku: candidate.sku ?? null,
              name: candidate.name,
              qty: short
            });
          }
        }

        const lineParticipants: OfferLineParticipant[] = [
          ...toLineParticipants(usedBuyUnits, 'BUY')
        ];

        return {
          discountPence: 0,
          autoAdd,
          meta: { groups, freeCount, samePool, lineDiscounts: [], lineParticipants }
        };
      }

      const sortedCheapest = [...discountSource].sort(
        (a, b) => a.unitPricePence - b.unitPricePence
      );
      const freeUnits = sortedCheapest.slice(0, freeCount);

      const discount = freeUnits.reduce((sum, u) => sum + u.unitPricePence, 0);

      if (!samePool) {
        const short = freeCount - getUnits.length;
        if (short > 0 && data.autoAddGetItem) {
          const candidate = [...buyUnits].sort((a, b) => a.unitPricePence - b.unitPricePence)[0];
          if (candidate) {
            autoAdd.push({
              reasonOfferId: o.id!,
              productId: candidate.productId ?? null,
              sku: candidate.sku ?? null,
              name: candidate.name,
              qty: short
            });
          }
        }
      }

      const lineDiscounts = toLineDiscounts(freeUnits, 'FREE');

      const lineParticipants: OfferLineParticipant[] = samePool
        ? toLineParticipants(usedBuyUnits, 'ELIGIBLE')
        : [...toLineParticipants(usedBuyUnits, 'BUY'), ...toLineParticipants(freeUnits, 'GET')];

      return {
        discountPence: discount,
        autoAdd,
        meta: { groups, freeCount, samePool, lineDiscounts, lineParticipants }
      };
    }

    case 'SPEND_X_GET_Y': {
      const data = p.data as OfferSpendXGetY;
      const spend = Math.max(0, data.spendPence);
      if (subtotal < spend) return { discountPence: 0, autoAdd: [] };

      const reward = data.reward;

      if (reward.type === 'AMOUNT_OFF') {
        const amt = Math.max(0, reward.amountPence);
        const discount = Math.min(amt, subtotal);
        return {
          discountPence: discount,
          autoAdd: [],
          meta: {
            spend,
            lineParticipants: [],
            lineDiscounts: []
          }
        };
      }

      if (reward.type === 'PERCENT_OFF') {
        const pct = clampInt(reward.percent, 0, 100);
        const discount = Math.floor((subtotal * pct) / 100);
        return {
          discountPence: discount,
          autoAdd: [],
          meta: {
            spend,
            pct,
            lineParticipants: [],
            lineDiscounts: []
          }
        };
      }

      return { discountPence: 0, autoAdd: [] };
    }

    default:
      return { discountPence: 0, autoAdd: [] };
  }
}

function clampInt(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function explodeUnits(lines: CartLine[]) {
  const units: Array<CartLine & { _unit: true }> = [];
  for (const l of lines) {
    const qty = Math.max(0, Math.floor(l.qty));
    for (let i = 0; i < qty; i++) units.push({ ...l, _unit: true });
  }
  return units;
}

function toLineDiscounts(
  discountedUnits: Array<CartLine & { _unit?: true }>,
  reason: 'FREE' | 'DISCOUNT'
): OfferLineDiscount[] {
  const map = new Map<
    string,
    {
      productId?: string | null;
      sku?: string | null;
      name: string;
      qty: number;
      amountPence: number;
    }
  >();

  for (const u of discountedUnits) {
    const key = lineKey(u);
    const prev = map.get(key);

    const unit = Math.max(0, Math.trunc(u.unitPricePence));

    if (!prev) {
      map.set(key, {
        productId: u.productId ?? null,
        sku: u.sku ?? null,
        name: u.name,
        qty: 1,
        amountPence: unit
      });
    } else {
      prev.qty += 1;
      prev.amountPence += unit;
    }
  }

  return Array.from(map.values()).map((x) => ({
    ...x,
    reason
  }));
}

function toLineParticipants(
  units: Array<CartLine & { _unit?: true }>,
  role: OfferLineParticipant['role']
): OfferLineParticipant[] {
  const map = new Map<
    string,
    {
      productId?: string | null;
      sku?: string | null;
      name: string;
      qty: number;
      role: OfferLineParticipant['role'];
    }
  >();

  for (const u of units) {
    const key = lineKey(u);
    const prev = map.get(key);
    if (!prev) {
      map.set(key, {
        productId: u.productId ?? null,
        sku: u.sku ?? null,
        name: u.name,
        qty: 1,
        role
      });
    } else {
      prev.qty += 1;
    }
  }

  return Array.from(map.values());
}

function matchLines(lines: CartLine[], rules: OfferTargetRule[]) {
  if (!rules?.length) return lines;
  return lines.filter((l) => rules.some((r) => matchRule(l, r)));
}

function matchRule(line: CartLine, rule: OfferTargetRule) {
  switch (rule.type) {
    case 'ALL_PRODUCTS':
      return true;
    case 'CATEGORY_IDS':
      return Boolean(line.categoryId && rule.ids.includes(line.categoryId));
    case 'PRODUCT_IDS':
      return Boolean(line.productId && rule.ids.includes(line.productId));
    case 'TAG_SLUGS':
      return Boolean(line.tags?.some((t) => rule.slugs.includes(t)));
    case 'COLLECTIONS':
      return Boolean(line.collection && rule.names.includes(line.collection));
    case 'NAME_PREFIX':
      return line.name.toLowerCase().startsWith(rule.prefix.toLowerCase());
    case 'SKU_PREFIX':
      return Boolean(line.sku && line.sku.toUpperCase().startsWith(rule.prefix.toUpperCase()));
    default:
      return false;
  }
}

function samePoolRules(a: OfferTargetRule[] | undefined, b: OfferTargetRule[] | undefined) {
  const aa = Array.isArray(a) ? a : [];
  const bb = Array.isArray(b) ? b : [];
  if (aa.length !== bb.length) return false;

  const normRules = (rules: OfferTargetRule[]) =>
    rules
      .map((r) => stableStringify(r))
      .sort()
      .join('|');

  return normRules(aa) === normRules(bb);
}

function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`;

  const obj = v as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${stableStringify(obj[k])}`).join(',')}}`;
}
