// src/app/api/offers/quote/route.ts
import { evaluateOffers, type CartLine } from '@/lib/offers-engine';
import { prisma } from '@/lib/prisma';
import type { OfferAdminForm } from '@/types/offers';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function ok(json: unknown) {
  return NextResponse.json(json, { status: 200 });
}

function bad(error: string, status = 400) {
  return NextResponse.json({ ok: false, error }, { status });
}

function asOfferList(v: unknown): OfferAdminForm[] {
  if (!Array.isArray(v)) return [];
  return v as OfferAdminForm[];
}

interface QuoteBody {
  lines?: CartLine[];
  code?: string | null;
}

interface OfferCardOut {
  offerId: string;
  name: string;
  kind: string;
  discountPence: number;
  meta: unknown | null;
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as unknown;
  if (!body || typeof body !== 'object') return bad('BAD_REQUEST');

  const { lines, code } = body as QuoteBody;
  if (!Array.isArray(lines)) return bad('LINES_REQUIRED');

  const setting = await prisma.appSetting.findUnique({
    where: { key: 'offers' }
  });

  const allOffers = asOfferList(setting?.value);

  const result = evaluateOffers(allOffers, {
    lines,
    code: typeof code === 'string' ? code : null
  });

  const mapOffer = (a: {
    offerId: string;
    name: string;
    kind: string;
    discountPence: number;
    meta?: unknown;
  }): OfferCardOut => ({
    offerId: a.offerId,
    name: a.name,
    kind: a.kind,
    discountPence: a.discountPence,
    meta: a.meta ?? null
  });

  return ok({
    ok: true,
    result: {
      subtotalPence: result.subtotalPence,

      // ✅ UI expects discountPence
      discountPence: result.discountTotalPence,

      applied: result.applied.map(mapOffer),

      // ✅ preview list
      eligible: result.eligible.map(mapOffer),

      autoAdd: result.autoAdd
    }
  });
}
