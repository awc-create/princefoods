// src/app/api/admin/offers/route.ts
import { getOffers, upsertOffer } from '@/lib/offers-store';
import { requireAdmin } from '@/lib/route-ctx';
import type { OfferAdminForm } from '@/types/offers';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function authFail(e: unknown) {
  const msg = e instanceof Error ? e.message : 'UNAUTHENTICATED';
  const status = msg === 'FORBIDDEN' ? 403 : 401;
  return NextResponse.json({ error: msg }, { status });
}

export async function GET() {
  try {
    await requireAdmin();
    const offers = await getOffers();
    return NextResponse.json({ offers });
  } catch (e) {
    return authFail(e);
  }
}

export async function POST(req: Request) {
  try {
    await requireAdmin();
    const body = (await req.json()) as OfferAdminForm;

    if (!body?.name?.trim()) {
      return NextResponse.json({ error: 'NAME_REQUIRED' }, { status: 400 });
    }
    if (!body?.payload?.kind) {
      return NextResponse.json({ error: 'PAYLOAD_REQUIRED' }, { status: 400 });
    }

    const saved = await upsertOffer(body);
    return NextResponse.json({ offer: saved });
  } catch (e) {
    return authFail(e);
  }
}
