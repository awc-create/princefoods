// src/app/api/admin/offers/[id]/route.ts
import { deleteOffer, getOffers, upsertOffer } from '@/lib/offers-store';
import { requireAdmin } from '@/lib/route-ctx';
import type { OfferAdminForm } from '@/types/offers';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface Params {
  params: { id: string };
}

function authFail(e: unknown) {
  const msg = e instanceof Error ? e.message : 'UNAUTHENTICATED';
  const status = msg === 'FORBIDDEN' ? 403 : 401;
  return NextResponse.json({ error: msg }, { status });
}

export async function GET(_req: Request, { params }: Params) {
  try {
    await requireAdmin();
    const offers = await getOffers();
    const offer = offers.find((o) => o.id === params.id);
    if (!offer) return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
    return NextResponse.json({ offer });
  } catch (e) {
    return authFail(e);
  }
}

export async function PUT(req: Request, { params }: Params) {
  try {
    await requireAdmin();
    const body = (await req.json()) as OfferAdminForm;
    const saved = await upsertOffer({ ...body, id: params.id });
    return NextResponse.json({ offer: saved });
  } catch (e) {
    return authFail(e);
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    await requireAdmin();
    await deleteOffer(params.id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return authFail(e);
  }
}
