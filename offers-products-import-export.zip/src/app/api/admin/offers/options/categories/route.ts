// src/app/api/admin/offers/options/categories/route.ts
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/route-ctx';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function authFail(e: unknown) {
  const msg = e instanceof Error ? e.message : 'UNAUTHENTICATED';
  const status = msg === 'FORBIDDEN' ? 403 : 401;
  return NextResponse.json({ error: msg }, { status });
}

export async function GET(req: Request) {
  try {
    await requireAdmin();

    const url = new URL(req.url);
    const q = (url.searchParams.get('q') ?? '').trim();

    // Adjust model/fields to YOUR schema:
    // If you use Category or ProductCategory etc, rename below.
    const categories = await prisma.category.findMany({
      where: q
        ? {
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { slug: { contains: q, mode: 'insensitive' } }
            ]
          }
        : undefined,
      orderBy: [{ name: 'asc' }],
      take: 200,
      select: {
        id: true,
        name: true,
        slug: true
      }
    });

    const options = categories.map((c) => ({
      id: c.id,
      label: c.name ?? 'Unnamed category',
      meta: c.slug ? `/${c.slug}` : undefined
    }));

    return NextResponse.json({ options });
  } catch (e) {
    return authFail(e);
  }
}
