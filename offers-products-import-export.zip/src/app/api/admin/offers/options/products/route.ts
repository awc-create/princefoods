// src/app/api/admin/offers/options/products/route.ts
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/route-ctx';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function authFail(e: unknown) {
  const msg = e instanceof Error ? e.message : 'UNAUTHENTICATED';
  const status = msg === 'FORBIDDEN' ? 403 : 401;
  return NextResponse.json({ error: msg }, { status });
}

// Returns PickerOption[] compatible with your OfferTargetPicker:
// { id, label, meta }
export async function GET(req: Request) {
  try {
    await requireAdmin();

    const url = new URL(req.url);
    const q = (url.searchParams.get('q') ?? '').trim();

    // Adjust model/fields to YOUR schema:
    // If your product model name differs (e.g. Product, StoreProduct), rename below.
    const products = await prisma.product.findMany({
      where: q
        ? {
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { sku: { contains: q, mode: 'insensitive' } }
            ]
          }
        : undefined,
      orderBy: [{ name: 'asc' }],
      take: 200,
      select: {
        id: true,
        name: true,
        sku: true
      }
    });

    const options = products.map((p) => ({
      id: p.id,
      label: p.name ?? 'Unnamed product',
      meta: p.sku ? `SKU: ${p.sku}` : undefined
    }));

    return NextResponse.json({ options });
  } catch (e) {
    return authFail(e);
  }
}
