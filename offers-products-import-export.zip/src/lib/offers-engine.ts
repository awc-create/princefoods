// src/lib/offers-engine.ts
import type {
  OfferAdminForm,
  OfferBOGOF,
  OfferPayload,
  OfferSpendXGetY,
  OfferTargetRule,
  OfferXForFixedPrice,
  OfferXForY
} from '@/types/offers';

export type Money = number; // pence

export interface CartLine {
  productId?: string | null;
  sku?: string | null;
  name: string;
  unitPricePence: Money;
  qty: number;

  // optional enrichment if you have it:
  categoryId?: string | null;
  tags?: string[] | null;
  collection?: string | null;
}

export interface OfferEvalInput {
  now?: Date;
  lines: CartLine[];

  // if code typed by user (optional)
  code?: string | null;
}

export interface OfferApplied {
  offerId: string;
  name: string;
  kind: OfferPayload['kind'];

  mode: OfferAdminForm['mode'];
  codeUsed: string | null;

  discountPence: Money;
  // If you later want: shippingDiscountPence etc.
  meta?: Record<string, unknown>;
}

export interface OfferEngineResult {
  subtotalPence: Money;
  applied: OfferApplied[];
  discountTotalPence: Money;

  // For BOGOF auto-add (optional)
  autoAdd: Array<{
    reasonOfferId: string;
    productId?: string | null;
    sku?: string | null;
    name: string;
    qty: number;
  }>;
}

export function evaluateOffers(
  allOffers: OfferAdminForm[],
  input: OfferEvalInput
): OfferEngineResult {
  const now = input.now ?? new Date();
  const subtotal = sumSubtotal(input.lines);

  // 1) eligible offers
  const eligible = allOffers
    .filter((o) => isOfferActive(o, now))
    .filter((o) => isModeEligible(o, input.code))
    .map((o) => ({ offer: o, eval: evalOffer(o, input.lines, subtotal) }))
    .filter((x) => x.eval.discountPence > 0 || x.eval.autoAdd.length > 0);

  // 2) resolve stacking (global-ish via each offer's stackingMode + priority)
  // Your model is per-offer stackingMode. We'll resolve like:
  // - If ANY chosen offer says STACK_ALLOWED -> can stack (but still cap via maxDiscountPerOrderPence etc)
  // - Otherwise, BEST_DISCOUNT_WINS or HIGHEST_PRIORITY_WINS depending on offer setting
  //
  // Practical store-friendly:
  // - If multiple eligible and some are BEST_DISCOUNT_WINS: pick best discount among those
  // - If some are HIGHEST_PRIORITY_WINS: pick highest priority among those
  // - If STACK_ALLOWED: stack all stack-allowed offers AND also allow one "best/priority" winner if you want
  //
  // To keep deterministic, we do:
  // A) collect stackAllowed offers first (if their stackingMode is STACK_ALLOWED)
  // B) among the rest, pick ONE winner using:
  //    - if any are HIGHEST_PRIORITY_WINS -> highest priority wins
  //    - else -> best discount wins
  const stackAllowed = eligible
    .filter((x) => x.offer.stackingMode === 'STACK_ALLOWED')
    .sort((a, b) => b.offer.priority - a.offer.priority);

  const nonStack = eligible
    .filter((x) => x.offer.stackingMode !== 'STACK_ALLOWED')
    .sort((a, b) => b.offer.priority - a.offer.priority);

  let winner: (typeof nonStack)[number] | null = null;

  if (nonStack.length) {
    const hasPriorityWins = nonStack.some((x) => x.offer.stackingMode === 'HIGHEST_PRIORITY_WINS');
    if (hasPriorityWins) {
      winner = nonStack[0]; // already sorted by priority desc
    } else {
      winner = nonStack.reduce((best, cur) =>
        cur.eval.discountPence > best.eval.discountPence ? cur : best
      );
    }
  }

  const chosen = [...stackAllowed, ...(winner ? [winner] : [])];

  // 3) apply caps + guardrails (prevent free order)
  const applied: OfferApplied[] = [];
  const autoAdd: OfferEngineResult['autoAdd'] = [];

  let discountTotal = 0;

  for (const c of chosen) {
    const o = c.offer;
    const codeUsed = resolveCodeUsed(o, input.code);

    // cap per offer
    let disc = c.eval.discountPence;
    if (typeof o.maxDiscountPerOrderPence === 'number') {
      disc = Math.min(disc, o.maxDiscountPerOrderPence);
    }

    // prevent free order
    if (o.preventFreeOrder) {
      const maxAllowed = Math.max(0, subtotal - 1); // leave 1p
      disc = Math.min(disc, maxAllowed - discountTotal);
      disc = Math.max(0, disc);
    }

    // if after caps it's 0, still keep autoAdd? (for BOGOF)
    if (disc > 0) {
      discountTotal += disc;
      applied.push({
        offerId: o.id!,
        name: o.name,
        kind: o.payload.kind,
        mode: o.mode,
        codeUsed,
        discountPence: disc,
        meta: c.eval.meta
      });
    }

    for (const a of c.eval.autoAdd) autoAdd.push(a);
  }

  return {
    subtotalPence: subtotal,
    applied,
    discountTotalPence: discountTotal,
    autoAdd
  };
}

/* ---------------- helpers ---------------- */

function sumSubtotal(lines: CartLine[]): Money {
  return lines.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);
}

function isOfferActive(o: OfferAdminForm, now: Date) {
  if (o.status !== 'ACTIVE') return false;
  if (o.startsAt) {
    const d = new Date(o.startsAt);
    if (!Number.isNaN(d.getTime()) && now < d) return false;
  }
  if (o.endsAt) {
    const d = new Date(o.endsAt);
    if (!Number.isNaN(d.getTime()) && now > d) return false;
  }
  return true;
}

function isModeEligible(o: OfferAdminForm, typedCode?: string | null) {
  if (o.mode === 'AUTO') return true;
  if (o.mode === 'CODE') return Boolean(typedCode && o.code && norm(typedCode) === norm(o.code));
  // BOTH
  if (!typedCode) return true; // can auto-apply
  if (!o.code) return true; // BOTH but no code set -> still allow auto
  return norm(typedCode) === norm(o.code);
}

function resolveCodeUsed(o: OfferAdminForm, typedCode?: string | null) {
  if (!typedCode) return null;
  if (!o.code) return null;
  return norm(typedCode) === norm(o.code) ? norm(typedCode) : null;
}

function norm(s: string) {
  return s.trim().toUpperCase().replace(/\s+/g, '');
}

interface Eval {
  discountPence: Money;
  autoAdd: OfferEngineResult['autoAdd'];
  meta?: Record<string, unknown>;
}

function evalOffer(o: OfferAdminForm, lines: CartLine[], subtotal: Money): Eval {
  const p = o.payload;

  switch (p.kind) {
    case 'PERCENT_OFF': {
      const pool = p.data.pool ?? [{ type: 'ALL_PRODUCTS' } satisfies OfferTargetRule];
      const matched = matchLines(lines, pool);
      const base = matched.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);
      const pct = clampInt(p.data.percent, 0, 100);
      const discount = Math.floor((base * pct) / 100);
      return { discountPence: discount, autoAdd: [], meta: { basePence: base, pct } };
    }

    case 'AMOUNT_OFF': {
      const pool = p.data.pool ?? [{ type: 'ALL_PRODUCTS' } satisfies OfferTargetRule];
      const matched = matchLines(lines, pool);
      const base = matched.reduce((sum, l) => sum + l.unitPricePence * l.qty, 0);
      const amt = Math.max(0, p.data.amountPence);
      return { discountPence: Math.min(amt, base), autoAdd: [], meta: { basePence: base } };
    }

    case 'X_FOR_Y': {
      const data = p.data as OfferXForY;
      const matched = matchLines(lines, data.pool);
      const units = explodeUnits(matched);
      if (units.length < data.buyQty) return { discountPence: 0, autoAdd: [] };

      // For each full group of buyQty, discount cheapest (buyQty - payQty) units
      const groups = Math.floor(units.length / data.buyQty);
      const freeCountPerGroup = Math.max(0, data.buyQty - data.payQty);
      const freeCount = groups * freeCountPerGroup;

      const cheapestFirst = [...units].sort((a, b) => a.unitPricePence - b.unitPricePence);
      const discount = cheapestFirst
        .slice(0, freeCount)
        .reduce((sum, u) => sum + u.unitPricePence, 0);

      return { discountPence: discount, autoAdd: [], meta: { groups, freeCount } };
    }

    case 'X_FOR_FIXED_PRICE': {
      const data = p.data as OfferXForFixedPrice;
      const matched = matchLines(lines, data.pool);
      const units = explodeUnits(matched);
      if (units.length < data.qty) return { discountPence: 0, autoAdd: [] };

      // For each group of qty, customer pays fixed price instead of sum of those qty units.
      // Choose the most expensive units to maximise discount? Typically you apply to cheapest or most expensive?
      // We'll apply to the MOST EXPENSIVE groupings to produce best customer value (common retail expectation).
      const groups = Math.floor(units.length / data.qty);
      if (groups <= 0) return { discountPence: 0, autoAdd: [] };

      const sortedDesc = [...units].sort((a, b) => b.unitPricePence - a.unitPricePence);

      let discount = 0;
      let idx = 0;
      for (let g = 0; g < groups; g++) {
        const groupUnits = sortedDesc.slice(idx, idx + data.qty);
        idx += data.qty;

        const groupSum = groupUnits.reduce((sum, u) => sum + u.unitPricePence, 0);
        const fixed = Math.max(0, data.pricePence);
        if (groupSum > fixed) discount += groupSum - fixed;
      }

      return { discountPence: discount, autoAdd: [], meta: { groups } };
    }

    case 'BOGOF': {
      const data = p.data as OfferBOGOF;

      const buyUnits = explodeUnits(matchLines(lines, data.buyPool));
      if (buyUnits.length < data.buyQty) return { discountPence: 0, autoAdd: [] };

      const groups = Math.floor(buyUnits.length / data.buyQty);
      const freeCount = groups * data.getQty;
      if (freeCount <= 0) return { discountPence: 0, autoAdd: [] };

      const getUnits = explodeUnits(matchLines(lines, data.getPool));

      // If customer already has eligible get items, discount them first (cheapest-first is typical for BOGOF)
      // If autoAddGetItem: we also return autoAdd suggestion if getUnits not enough.
      const sortedGet = [...getUnits].sort((a, b) => a.unitPricePence - b.unitPricePence);

      const discountUnits = sortedGet.slice(0, freeCount);
      const discount = discountUnits.reduce((sum, u) => sum + u.unitPricePence, 0);

      const autoAdd: OfferEngineResult['autoAdd'] = [];
      const short = freeCount - sortedGet.length;

      if (short > 0 && data.autoAddGetItem) {
        // We can't magically choose a SKU unless you decide a rule.
        // For now, pick the cheapest buy item as the default auto-add suggestion.
        const candidate = [...buyUnits].sort((a, b) => a.unitPricePence - b.unitPricePence)[0];
        if (candidate) {
          autoAdd.push({
            reasonOfferId: o.id!,
            productId: candidate.productId ?? null,
            sku: candidate.sku ?? null,
            name: candidate.name,
            qty: short
          });
        }
      }

      return {
        discountPence: discount,
        autoAdd,
        meta: { groups, freeCount, discountedUnits: discountUnits.length }
      };
    }

    case 'SPEND_X_GET_Y': {
      const data = p.data as OfferSpendXGetY;
      const spend = Math.max(0, data.spendPence);
      if (subtotal < spend) return { discountPence: 0, autoAdd: [] };

      const reward = data.reward;
      if (reward.type === 'AMOUNT_OFF') {
        const amt = Math.max(0, reward.amountPence);
        return { discountPence: Math.min(amt, subtotal), autoAdd: [], meta: { spend } };
      }

      if (reward.type === 'PERCENT_OFF') {
        const pct = clampInt(reward.percent, 0, 100);
        const discount = Math.floor((subtotal * pct) / 100);
        return { discountPence: discount, autoAdd: [], meta: { spend, pct } };
      }

      return { discountPence: 0, autoAdd: [] };
    }

    default:
      return { discountPence: 0, autoAdd: [] };
  }
}

function clampInt(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/** Expand cart lines into per-unit list so "cheapest N units" logic is easy. */
function explodeUnits(lines: CartLine[]) {
  const units: Array<CartLine & { _unit: true }> = [];
  for (const l of lines) {
    const qty = Math.max(0, Math.floor(l.qty));
    for (let i = 0; i < qty; i++) units.push({ ...l, _unit: true });
  }
  return units;
}

/** Match a line if ANY rule matches (OR semantics). */
function matchLines(lines: CartLine[], rules: OfferTargetRule[]) {
  if (!rules?.length) return lines;

  return lines.filter((l) => rules.some((r) => matchRule(l, r)));
}

function matchRule(line: CartLine, rule: OfferTargetRule) {
  switch (rule.type) {
    case 'ALL_PRODUCTS':
      return true;

    case 'CATEGORY_IDS':
      return Boolean(line.categoryId && rule.ids.includes(line.categoryId));

    case 'PRODUCT_IDS':
      return Boolean(line.productId && rule.ids.includes(line.productId));

    case 'TAG_SLUGS':
      return Boolean(line.tags?.some((t) => rule.slugs.includes(t)));

    case 'COLLECTIONS':
      return Boolean(line.collection && rule.names.includes(line.collection));

    case 'NAME_PREFIX':
      return line.name.toLowerCase().startsWith(rule.prefix.toLowerCase());

    case 'SKU_PREFIX':
      return Boolean(line.sku && line.sku.toUpperCase().startsWith(rule.prefix.toUpperCase()));

    default:
      return false;
  }
}
