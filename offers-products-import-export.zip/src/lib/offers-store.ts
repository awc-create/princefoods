// src/lib/offers-store.ts
import { prisma } from '@/lib/prisma';
import type { OfferAdminForm } from '@/types/offers';

const KEY = 'offers';

function safeArray(v: unknown): OfferAdminForm[] {
  if (!Array.isArray(v)) return [];
  return v as OfferAdminForm[];
}

export async function getOffers(): Promise<OfferAdminForm[]> {
  const row = await prisma.appSetting.findUnique({ where: { key: KEY } });
  if (!row) return [];
  return safeArray(row.value);
}

export async function saveOffers(next: OfferAdminForm[]) {
  await prisma.appSetting.upsert({
    where: { key: KEY },
    create: { key: KEY, value: next as unknown as object },
    update: { value: next as unknown as object }
  });
}

export async function upsertOffer(offer: OfferAdminForm): Promise<OfferAdminForm> {
  const all = await getOffers();
  const id = offer.id ?? crypto.randomUUID();
  const clean: OfferAdminForm = { ...offer, id };

  const idx = all.findIndex((x) => x.id === id);
  const next = idx >= 0 ? all.map((x) => (x.id === id ? clean : x)) : [clean, ...all];

  await saveOffers(next);
  return clean;
}

export async function deleteOffer(id: string) {
  const all = await getOffers();
  await saveOffers(all.filter((x) => x.id !== id));
}
