// src/app/api/admin/offers/[id]/email-blast/route.ts
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Role = 'HEAD' | 'STAFF' | 'VIEWER';
type Scope = 'ALL_CUSTOMERS' | 'SELECTED_USERS';

interface SessionUserWithRole {
  role?: Role | null;
}

const hasRole = (u: unknown): u is SessionUserWithRole =>
  !!u && typeof u === 'object' && 'role' in (u as Record<string, unknown>);

function forbid() {
  return NextResponse.json({ ok: false, error: 'Forbidden' }, { status: 403 });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    const role: Role | undefined = hasRole(session?.user)
      ? (session.user.role ?? undefined)
      : undefined;

    if (!role || (role !== 'HEAD' && role !== 'STAFF')) return forbid();

    const { id: offerId } = await ctx.params;

    const body = (await req.json().catch(() => null)) as null | {
      scope?: Scope;
      userIds?: string[];
      subject?: string;
      message?: string | null;
    };

    if (!body) {
      return NextResponse.json({ ok: false, error: 'Invalid JSON' }, { status: 400 });
    }

    const scope: Scope = body.scope ?? 'ALL_CUSTOMERS';
    const subject = (body.subject ?? '').trim();
    const message = typeof body.message === 'string' ? body.message.trim() : null;
    const userIds = Array.isArray(body.userIds) ? body.userIds.filter(Boolean) : [];

    console.log('🟡 [offer-email-blast] create called', {
      offerId,
      scope,
      subject,
      userIdsCount: userIds.length
    });

    if (!subject) {
      return NextResponse.json({ ok: false, error: 'Subject required' }, { status: 400 });
    }

    if (scope === 'SELECTED_USERS' && userIds.length === 0) {
      return NextResponse.json({ ok: false, error: 'Select at least 1 user' }, { status: 400 });
    }

    const offer = await prisma.offer.findUnique({
      where: { id: offerId },
      select: { id: true }
    });

    if (!offer) {
      return NextResponse.json({ ok: false, error: 'NOT_FOUND' }, { status: 404 });
    }

    const customers =
      scope === 'ALL_CUSTOMERS'
        ? await prisma.user.findMany({
            where: {
              email: { not: '' },
              deletedAt: null,
              isAnonymized: false
            },
            select: { id: true, email: true }
          })
        : await prisma.user.findMany({
            where: {
              id: { in: userIds },
              email: { not: '' },
              deletedAt: null,
              isAnonymized: false
            },
            select: { id: true, email: true }
          });

    console.log('🟡 [offer-email-blast] recipients found:', customers.length);

    if (customers.length === 0) {
      return NextResponse.json(
        { ok: false, error: 'No recipients found (missing emails?).' },
        { status: 400 }
      );
    }

    const blast = await prisma.offerEmailBlast.create({
      data: {
        offerId,
        subject,
        message,
        scope,
        userIds: scope === 'SELECTED_USERS' ? userIds : undefined,
        recipients: {
          createMany: {
            data: customers.map((u) => ({
              userId: u.id,
              email: u.email
            })),
            skipDuplicates: true
          }
        }
      },
      select: { id: true }
    });

    console.log('🟢 [offer-email-blast] blast created:', blast.id);

    const origin = new URL(req.url).origin;

    const runRes = await fetch(`${origin}/api/admin/offers/blasts/${blast.id}/run?limit=500`, {
      method: 'POST',
      headers: {
        cookie: req.headers.get('cookie') ?? ''
      },
      cache: 'no-store'
    });

    const runJson = (await runRes.json().catch(() => null)) as unknown;

    console.log('🟢 [offer-email-blast] run response:', runJson);

    return NextResponse.json({
      ok: true,
      blastId: blast.id,
      recipients: customers.length,
      run: runJson
    });
  } catch (e) {
    console.error('[POST /api/admin/offers/[id]/email-blast] error', e);
    return NextResponse.json(
      { ok: false, error: 'Failed to create/send offer blast' },
      { status: 500 }
    );
  }
}
