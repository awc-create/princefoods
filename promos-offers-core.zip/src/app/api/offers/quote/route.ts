// src/app/api/offers/quote/route.ts
import { evaluateOffers, type CartLine } from '@/lib/offers-engine';
import { getOffers } from '@/lib/offers-store';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const body = (await req.json()) as {
    lines: CartLine[];
    code?: string | null;
  };

  if (!Array.isArray(body?.lines)) {
    return NextResponse.json({ error: 'LINES_REQUIRED' }, { status: 400 });
  }

  const offers = await getOffers();
  const result = evaluateOffers(offers, {
    lines: body.lines,
    code: body.code ?? null
  });

  return NextResponse.json({ result });
}
