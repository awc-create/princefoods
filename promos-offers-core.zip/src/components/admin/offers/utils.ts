// src/components/admin/offers/utils.ts
import type { OfferRow } from './types';

function penceToGBP(pence: number) {
  const v = Number.isFinite(pence) ? pence : 0;
  return new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(v / 100);
}

export function offerLabel(o: OfferRow) {
  if (o.kind === 'BOGOF') return `Buy ${o.buyQty} get ${o.getQty ?? 1} free`;
  if (o.kind === 'X_FOR_Y') return `Buy ${o.buyQty} pay ${o.payQty ?? 1}`;
  if (o.kind === 'X_FOR_FIXED_PRICE') return `${o.buyQty} for ${penceToGBP(o.pricePence ?? 0)}`;
  return '—';
}

export function fmtDate(d: string | null) {
  if (!d) return '—';
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString();
}

export function clampInt(n: number, min: number, max: number) {
  const x = Math.trunc(n);
  return Math.max(min, Math.min(max, x));
}

export function dedupeIds(ids: string[]) {
  return Array.from(new Set(ids.filter(Boolean)));
}
