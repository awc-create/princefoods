// src/components/admin/offers/types.ts

export type OfferStatus = 'ACTIVE' | 'PAUSED' | 'EXPIRED';

// ✅ UI matches engine kinds (the 3 we’re supporting in the admin for now)
export type OfferKind = 'BOGOF' | 'X_FOR_Y' | 'X_FOR_FIXED_PRICE';

export type OfferTargetType = 'SITE_WIDE' | 'CATEGORIES' | 'PRODUCTS';

// ✅ needed by OfferTargetPicker.tsx
export interface PickerOption {
  id: string;
  label: string;
  meta?: string;
}

export interface OfferRow {
  id: string;
  name: string;
  kind: OfferKind;
  status: OfferStatus;

  buyQty: number;
  getQty: number | null; // BOGOF
  payQty: number | null; // X_FOR_Y
  pricePence: number | null; // X_FOR_FIXED_PRICE (eg 2 for £1)

  targetType: OfferTargetType;

  startsAt: string | null;
  endsAt: string | null;

  maxUsesTotal: number | null;

  createdAt: string;
  updatedAt: string;

  appliedCount: number;
}

export interface CreateOfferBody {
  name: string;
  kind: OfferKind;
  status: OfferStatus;

  buyQty: number;
  getQty?: number | null;
  payQty?: number | null;
  pricePence?: number | null;

  targetType: OfferTargetType;

  categoryIds?: string[];
  productIds?: string[];

  startsAt: string | null;
  endsAt: string | null;
  maxUsesTotal: number | null;
}
