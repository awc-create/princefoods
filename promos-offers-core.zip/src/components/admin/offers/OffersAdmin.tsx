// src/components/admin/offers/OffersAdmin.tsx
'use client';

import { useEffect, useState } from 'react';
import OffersTable from './OffersTable';
import type { OfferRow } from './types';

export default function OffersAdmin() {
  const [rows, setRows] = useState<OfferRow[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch('/api/admin/offers', { cache: 'no-store' });
    const json = await res.json();
    setRows(json.offers ?? []);
    setLoading(false);
  }

  useEffect(() => {
    void load();
  }, []);

  async function toggle(o: OfferRow) {
    await fetch(`/api/admin/offers/${o.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: o.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE' })
    });
    await load();
  }

  async function remove(o: OfferRow) {
    if (!confirm(`Delete ${o.name}?`)) return;
    await fetch(`/api/admin/offers/${o.id}`, { method: 'DELETE' });
    await load();
  }

  if (loading) return <div>Loading…</div>;

  return <OffersTable rows={rows} onEdit={() => {}} onToggle={toggle} onDelete={remove} />;
}
